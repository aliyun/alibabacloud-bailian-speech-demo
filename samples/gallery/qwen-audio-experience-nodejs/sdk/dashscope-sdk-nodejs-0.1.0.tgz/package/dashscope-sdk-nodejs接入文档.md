# Qwen Audio Node.js SDK 接入指南

`dashscope-sdk-nodejs` 提供语音合成、实时语音识别、录音文件转写和实时语音对话的 Node.js 客户端，支持 ESM、CommonJS 和 TypeScript。

**适用版本**：SDK `0.1.0`。

## 前提条件

- 已安装 Node.js 18 或以上版本。SDK 仅用于服务端，不支持在浏览器中直接使用。
- 已开通所用模型服务，并取得 API Key；按需准备业务空间 ID。
- 运行环境可访问所使用的服务域名。实际服务调用可能产生费用。

## 获取与安装

解压 `dashscope-sdk-nodejs-0.1.0.zip`，将 `sdk/dashscope-sdk-nodejs-0.1.0.tgz` 复制到业务项目的 `vendor/` 目录并安装：

```bash
npm install ./vendor/dashscope-sdk-nodejs-0.1.0.tgz
```

请保留 `.tgz` 文件，以便 CI 和其他环境复现安装。运行时依赖 `ws` 会从项目配置的 npm 源下载。

## 接口文档

| 能力 | 类 | 导入路径 | 调用方式 | 文档 |
| --- | --- | --- | --- | --- |
| 语音合成 | `SpeechSynthesizer` | `dashscope-sdk-nodejs/tts` | 一次性合成或流式输入、流式输出 | [语音合成](./dashscope-sdk-nodejs语音合成文档.md) |
| 实时语音识别 | `RecognitionClient` | `dashscope-sdk-nodejs/asr` | 流式发送音频，通过事件接收文本 | [实时语音识别](./dashscope-sdk-nodejs实时语音识别文档.md) |
| 录音文件转写 | `TranscriptionClient` | `dashscope-sdk-nodejs/asr` | 提交任务、轮询状态、下载结果 | [录音文件转写](./dashscope-sdk-nodejs录音文件转写文档.md) |
| 实时语音对话 | `RealtimeClient` | `dashscope-sdk-nodejs/realtime` | 会话配置、音频收发、文本转写、工具调用 | [实时语音对话](./dashscope-sdk-nodejs实时语音对话文档.md) |

## 导入

```js
import { SpeechSynthesizer } from 'dashscope-sdk-nodejs/tts'
import { RecognitionClient, TranscriptionClient } from 'dashscope-sdk-nodejs/asr'
import { RealtimeClient } from 'dashscope-sdk-nodejs/realtime'
import { DashScopeError } from 'dashscope-sdk-nodejs'
```

CommonJS 中使用 `require()` 导入相同入口。各接口文档中的完整 JavaScript 示例可保存为 `.mjs` 文件后运行。

## 连接配置

四个客户端均支持以下构造参数，可与模型、音色或音频参数一同传入：

| 参数 | 说明 |
| --- | --- |
| `apiKey` | API Key；省略时读取 `DASHSCOPE_API_KEY`，两者均未提供时构造失败 |
| `workspaceId` | 业务空间 ID；省略时读取 `DASHSCOPE_WORKSPACE_ID` |
| `baseUrl` | 服务域名或地址，默认 `dashscope.aliyuncs.com` |
| `headers` | 额外请求头，避免重复设置鉴权和业务空间请求头 |
| `onTrace` | 可选传输事件回调，记录连接、消息、音频字节数和错误；URL 与业务数据须按需脱敏 |

```js
const connectionOptions = {
  apiKey: process.env.DASHSCOPE_API_KEY,
  workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
  baseUrl: 'dashscope.aliyuncs.com',
}
```

SDK 不自动加载 `.env` 文件，使用 `.env` 时请由应用自行加载。服务域名通过 `baseUrl` 参数指定，SDK 不读取服务地址类环境变量。

切换地域时修改 `baseUrl`，例如新加坡公共域名为 `dashscope-intl.aliyuncs.com`。使用业务空间专属域名时，填写对应域名。`workspaceId` 只用于生成 `X-DashScope-WorkSpace` 请求头，不改变域名。

只填写域名时，SDK 自动补全协议与接口路径。录音文件转写的 `baseUrl` 作为 HTTP 地址前缀，不要填写完整提交接口路径；其他能力的自定义地址规则见对应接口文档。

## 传输事件（ClientTraceEvent）

通过 `onTrace` 接收 WebSocket 或 HTTP 的传输事件，回调类型为 `(event: ClientTraceEvent) => void | Promise<void>`。回调异常不会影响请求。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `timestamp` | `number` | 事件时间，Unix 时间戳，单位毫秒 |
| `transport` | `'websocket' \| 'http'` | 传输方式 |
| `event` | `'connect' \| 'open' \| 'send' \| 'receive' \| 'close' \| 'error'` | 事件类型 |
| `url` | `string` | 连接或请求地址 |
| `data` | `unknown`，可选 | 协议消息或错误信息 |
| `bytes` | `number`，可选 | 音频或消息的字节数 |
| `method` | `string`，可选 | HTTP 请求方法 |
| `status` | `number`，可选 | HTTP 响应状态码 |

传输事件不包含请求头，二进制帧仅记录字节数。URL 和 `data` 仍可能包含签名参数、文本或其他业务数据，记录前须脱敏。

## 错误处理与安全

各客户端提供 `DashScopeError`，可从主入口或相应子路径导入。请按接口文档处理任务失败、连接中断和资源释放；SDK 不自动重连或重试。

不要将 API Key 写入前端代码、日志或源码仓库。建议错误日志仅记录 `name`、`code`、`requestId` 和 `taskId`；`message`、`raw`、`cause` 及传输回调中的 URL、业务数据可能包含敏感信息，记录前应脱敏。

## 运行示例

发布包中的 `examples/` 目录包含各能力的可运行示例。进入该目录，执行 `npm install` 并设置 `DASHSCOPE_API_KEY`，然后按照示例目录中的说明运行。
