# Qwen Audio 语音合成 Node.js SDK

本文介绍如何通过 `dashscope-sdk-nodejs` 调用 Qwen Audio 语音合成服务，以及 `SpeechSynthesizer` 的参数、方法、事件与示例代码。

**适用版本**：SDK `0.1.0`。

其他能力的接口文档：[实时语音识别](./dashscope-sdk-nodejs实时语音识别文档.md)、[录音文件转写](./dashscope-sdk-nodejs录音文件转写文档.md)、[实时语音对话](./dashscope-sdk-nodejs实时语音对话文档.md)。

## 前提条件

- 已开通所使用的模型服务，并取得对应地域的 API Key；按需准备业务空间 ID。
- 已安装 Node.js 18 或以上版本。此 SDK 是服务端 SDK，不支持在浏览器中直接使用。
- 实际服务调用可能产生费用。模型、音色、可用地域、配额及参数能力以对应服务文档为准。
- 将 API Key 设置为环境变量 `DASHSCOPE_API_KEY`，或通过客户端构造参数传入。按需设置 `DASHSCOPE_WORKSPACE_ID`。

**重要**：不要将 API Key 写入前端代码、日志或源码仓库。SDK 会读取进程环境变量，但不会自动加载 `.env` 文件；如使用 `.env`，请由应用自行加载。

## 安装与导入

SDK 以本地安装包形式分发，不发布到公开 npm 仓库。从发布包的 `sdk/` 目录取得 `dashscope-sdk-nodejs-0.1.0.tgz`，放入业务项目（例如 `vendor/` 目录）后安装：

```bash
npm install ./vendor/dashscope-sdk-nodejs-0.1.0.tgz
```

安装后，`package.json` 中的依赖记录为 `file:vendor/dashscope-sdk-nodejs-0.1.0.tgz`。请将该 `.tgz` 文件随项目纳入版本管理或内部制品库，以便 CI 和其他成员复现安装。运行时依赖 `ws` 仍从项目配置的 npm 源安装。

ESM 和 TypeScript 可从子路径或主入口导入：

```ts
import { SpeechSynthesizer, DashScopeError } from 'dashscope-sdk-nodejs/tts'
```

CommonJS 可使用 `require`：

```js
const { SpeechSynthesizer } = require('dashscope-sdk-nodejs/tts')
```

下文完整示例使用 ESM，保存为对应的 `.mjs` 文件后运行。TypeScript 代码中的 `?` 表示可选参数或字段，`Promise<T>` 表示异步返回 `T`。

## 接口地址

SDK 默认连接 `dashscope.aliyuncs.com`。语音合成使用 WebSocket 地址 `wss://{host}/api-ws/v1/inference`，`{host}` 由 `baseUrl` 决定：只给域名时协议与路径由 SDK 补全。切换地域或改用业务空间专属域名，把 `baseUrl` 换成下表中的域名即可。

| 场景 | `baseUrl` 取值 |
| --- | --- |
| 华北2（北京）公共域名 | 省略，或 `dashscope.aliyuncs.com` |
| 新加坡公共域名 | `dashscope-intl.aliyuncs.com` |
| 华北2（北京）业务空间专属域名 | `{WorkspaceId}.cn-beijing.maas.aliyuncs.com` |
| 新加坡业务空间专属域名 | `{WorkspaceId}.ap-southeast-1.maas.aliyuncs.com` |

**重要**：不同地域的凭据和模型可用性可能不同。切换域名时，请同时核对 API Key、业务空间、模型和音色。`workspaceId` 只用于生成 `X-DashScope-WorkSpace` 请求头，不会改变域名；使用业务空间专属域名须自行写入 `baseUrl`。

## 通用配置（BaseClientOptions）

`SpeechSynthesizerOptions` 继承以下通用参数。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `apiKey` | `string` | 条件必填 | 显式传入的 API Key 优先；省略时读取 `DASHSCOPE_API_KEY`。两者均未提供时构造失败。 |
| `workspaceId` | `string` | 否 | 省略时读取 `DASHSCOPE_WORKSPACE_ID`。提供非空值时附带 `X-DashScope-WorkSpace` 请求头，不改变域名。 |
| `baseUrl` | `string` | 否 | 服务地址，默认 `dashscope.aliyuncs.com`。可只给域名，SDK 补全 `wss://` 与 `/api-ws/v1/inference`；已带路径的完整地址原样使用，可用于自定义网关。 |
| `headers` | `Record<string, string>` | 否 | 额外请求头。请避免重复设置鉴权头或业务空间头；显式提供的同名 `Authorization` 可以覆盖默认鉴权值。 |
| `onTrace` | `(event: ClientTraceEvent) => void \| Promise<void>` | 否 | 传输事件回调，记录连接、上下行消息和错误。回调异常不影响请求；URL 和业务数据须按需脱敏，字段见[接入文档](./dashscope-sdk-nodejs接入文档.md)。 |

`workspaceId` 的非空值须是由字母、数字或连字符组成的 1–63 字符 DNS label，不能以连字符开头或结尾。传空字符串表示显式不使用业务空间，不再读取环境变量中的业务空间 ID。

设置 `baseUrl` 不会绕过 API Key 与业务空间参数的构造期校验。非字符串 `baseUrl`、无法解析的地址或不受支持的协议（仅接受 `http`、`https`、`ws`、`wss` 或不带协议的域名）均在构造时抛出 `invalid_request_error`。

## 事件监听

`SpeechSynthesizer` 支持以下方法。

| 方法 | 参数 | 返回值 | 说明 |
| --- | --- | --- | --- |
| `on(event, listener)` | 事件名、监听函数 | `this` | 持续监听事件。事件名与负载在 TypeScript 中有类型提示。 |
| `once(event, listener)` | 事件名、监听函数 | `this` | 仅监听一次。 |
| `off(event, listener?)` | 事件名、可选监听函数 | `this` | 提供函数时移除该监听；省略时移除该事件的全部监听。 |
| `removeAllListeners()` | 无 | `this` | 移除全部事件的监听。 |

**重要**：在启动任务前注册监听器，使用 `try/catch/finally` 处理异步调用失败并释放资源。未注册 `error` 监听器时，SDK 会通过 `console.warn` 输出错误消息；建议注册监听器并对日志脱敏。

监听器的异常由应用负责处理。SDK 不会等待异步监听器返回的 Promise。

## SpeechSynthesizer

**导入路径**：`dashscope-sdk-nodejs/tts`，也可从主入口导入。

提供两种调用方式：

| 调用方式 | 输入 | 输出 | 典型场景 |
| --- | --- | --- | --- |
| `synthesize()` | 一次性发送完整文本 | `audio` 事件逐块接收；Promise 返回完整 `Buffer` | 短文本、生成音频文件 |
| `begin()` → `sendText()` → `end()` | 多次发送文本片段 | `audio` 事件逐块接收；`end()` 返回完整 `Buffer` | 对接大模型流式文本 |

**任务流程**：建立 WebSocket → 发送 `run-task` → 收到 `task-started` → 发送一个或多个 `continue-task` → 发送 `finish-task` → 收到 `task-finished` → 关闭连接。音频可以在发送文本期间返回。

一个实例同一时间只运行一个任务。每次 `begin()` 都建立新连接并生成新任务 ID；正常结束后可再次使用同一实例。

### 构造方法

```ts
new SpeechSynthesizer(options: SpeechSynthesizerOptions)
```

### SpeechSynthesizerOptions

除通用配置外，还支持以下参数。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `model` | `string` | 否 | SDK 默认 `qwen-audio-3.1-tts-flash`。 |
| `voice` | `string` | 是 | 音色 ID。须与模型及地域匹配，参见 [官方音色列表](https://help.aliyun.com/zh/model-studio/qwen-audio-tts-voice-list)。 |
| `format` | `'pcm' \| 'wav' \| 'mp3' \| 'opus'` | 否 | SDK 类型支持的音频格式。省略时不传，由模型服务确定默认值。保存文件时建议显式指定。 |
| `sampleRate` | `8000 \| 16000 \| 22050 \| 24000 \| 44100 \| 48000` | 否 | 采样率，单位 Hz。省略时由服务端决定；具体可用值须与模型、编码匹配。 |
| `volume` | `number` | 否 | 音量。参数约定为 `[0,100]`，默认 50；SDK 省略时不注入该值。 |
| `rate` | `number` | 否 | 语速。参数约定为 `[0.5,2.0]`，默认 1.0；省略时由服务端决定。 |
| `pitch` | `number` | 否 | 音调。参数约定为 `[0.5,2.0]`，默认 1.0；省略时由服务端决定。 |
| `wordTimestampEnabled` | `boolean` | 否 | 是否请求字级时间戳。参数约定默认 `false`；有数据时通过 `sentenceEnd.words` 返回。 |
| `languageHints` | `string[]` | 否 | 目标语言提示。当前参数约定为仅首个元素生效，具体以模型服务为准。 |
| `instruction` | `string` | 否 | 方言、情感或角色等控制指令，须使用支持该能力的模型。 |
| `parameters` | `TtsSynthesisParameters & { voice?: never }` | 否 | 扩展参数，使用服务端字段名，例如 `bit_rate`、`seed`；禁止包含 `voice`，否则构造时抛出参数错误。 |
| `dataInspection` | `'enable' \| 'disable'` | 否 | 设置后发送 `X-DashScope-DataInspection` 请求头；省略时不发送。 |
| `connectTimeoutMs` | `number` | 否 | WebSocket 建连超时，默认 10000 ms。请设置正数；`0` 不表示禁用。 |
| `taskTimeoutMs` | `number` | 否 | 分别等待 `task-started`、`task-finished` 的超时，默认 60000 ms；`0` 禁用这两类确认超时。须为有限非负数。 |

**说明**：表中的格式、参数范围及能力是 SDK 类型或参数约定，不表示任意模型均支持。SDK 不校验所有服务端参数范围；不支持的值由服务端返回错误。

`taskTimeoutMs` 不限制已启动流的总时长。两次 `sendText()` 间隔需小于服务要求的 23 秒；SDK 没有独立的发送间隔计时器。

### 扩展参数（TtsSynthesisParameters）

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `text_type` | `'PlainText'` | 否 | SDK 默认注入 `PlainText`。 |
| `enable_ssml` | `boolean` | 否 | 开启 SSML；一个任务只允许一次非空 `sendText()`，须一次发送完整 SSML。 |
| `format`、`sample_rate` | `TtsAudioFormat`、`TtsSampleRate` | 否 | 与顶层格式、采样率对应。 |
| `volume`、`rate`、`pitch` | `number` | 否 | 与顶层音量、语速、音调对应。 |
| `word_timestamp_enabled` | `boolean` | 否 | 与顶层 `wordTimestampEnabled` 对应。 |
| `language_hints` | `string[]` | 否 | 与顶层 `languageHints` 对应。 |
| `instruction` | `string` | 否 | 合成控制指令。 |
| `bit_rate` | `number` | 否 | 码率，单位 kbps；参数约定仅用于 MP3/Opus，默认 32，范围 `[6,510]`。 |
| `seed` | `number` | 否 | 随机种子，参数约定范围 `[0,65535]`。 |
| 其他字段 | `unknown` | 否 | 按服务端协议透传。 |

`TtsSynthesisParameters` 保留已声明字段的具体类型，未声明的服务端扩展字段为 `unknown`。线协议类型 `TtsParameters` 在此基础上增加必填 `voice: string`；构造客户端必须使用顶层 `voice`。类型声明在编译期拒绝非 `undefined` 的 `voice`；`parameters` 中只要出现 `voice` 键（包括 `voice: undefined`），构造时都会在运行时抛出参数错误。

顶层显式提供的 `format`、`sampleRate`、`volume`、`rate`、`pitch`、`wordTimestampEnabled`、`languageHints`、`instruction` 会覆盖 `parameters` 中对应字段。

### 属性

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `isRunning` | `boolean`，只读 | 当前是否存在运行中的任务，包括建连、等待启动、合成和等待结束阶段。不等同于“已可发送文本”。 |

### synthesize() - 一次性合成

```ts
synthesize(text: string): Promise<Buffer>
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `text` | `string` | 是 | 完整文本，不能是空字符串或纯空白，长度不超过 20000。 |

**返回值**：完整音频 `Buffer`。内部执行 `begin()` → `sendText()` → `end()`，不会自动拆分长文本。

**异常**：参数不合法、已有任务运行、建连失败、服务端任务失败或超时等情况会拒绝 Promise。

### begin() - 开启流式合成

```ts
begin(): Promise<void>
```

**返回值**：收到服务端 `task-started` 后兑现，不返回任务 ID；任务 ID 通过 `started` 事件获得。必须等待 `begin()` 完成后再调用 `sendText()`。

### sendText() - 发送文本片段

```ts
sendText(text: string): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `text` | `string` | 是 | 当前片段，单次不超过 20000，单个任务累计不超过 200000。长度按 JavaScript `string.length` 计算。 |

**返回值**：无。已启动任务中的空字符串被忽略。启动前、结束阶段或任务失败后调用可能同步抛出错误。

**重要**：最后一个片段发送后必须调用 `end()`，使服务端处理剩余文本并结束任务。`parameters.enable_ssml: true` 时，第二次非空发送会同步抛出参数错误；空字符串不占用次数，下一任务重新计数。普通文本仍可多次发送。

### end() - 结束流式合成

```ts
end(): Promise<Buffer>
```

发送一次 `finish-task` 并等待服务端 `task-finished`。

**返回值**：拼接后的完整音频 `Buffer`。等待结束期间重复调用返回同一 Promise；任务已清理后再次调用不返回旧任务结果。

**重要**：即使监听 `audio` 事件，SDK 仍缓存本任务的全部音频。`end()` 返回的是原始字节拼接，不转码、不添加容器头，也不负责写文件。不要修改 `audio` 事件收到的 Buffer，否则可能影响最终拼接结果。

### cancel() - 请求取消合成

```ts
cancel(): void
```

向已启动任务发送带 `directive: 'cancel'` 的 `finish-task`，之后不再允许追加文本。不会立即关闭连接，也不保证已在途音频立即停止到达。

**返回值**：无。未启动、已在结束阶段或重复调用时不执行操作。取消请求后仍可在任务结束前调用 `end()` 等待服务端确认，并取得已接收音频。

### close() - 本地关闭连接

```ts
close(code?: number, reason?: string): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `code` | `number` | 否 | WebSocket 关闭码，默认 1000。 |
| `reason` | `string` | 否 | 关闭原因，默认 `client closing`；须满足 WebSocket 关闭帧限制。 |

关闭连接后立即清理本地任务，并以 `code: 'cancelled'` 的错误拒绝正在等待的启动或结束 Promise。无连接时不执行操作。OPEN 状态下非法关闭码（例如 1006）或超过 123 字节的 UTF-8 原因会同步抛出底层异常；任务和连接保持原状，修正参数后可再次关闭。

### 事件（TtsEvents）

| 事件 | 负载类型 | 说明 |
| --- | --- | --- |
| `started` | `{ taskId: string }` | 服务端确认任务已启动。 |
| `audio` | `Buffer` | 一个音频二进制块，可在合成过程中多次触发。 |
| `sentenceBegin` | `{ index: number; text: string }` | 句子开始合成。 |
| `sentenceEnd` | `{ index: number; text: string; characters?: number; words?: TtsWord[]; usage?: TtsUsage }` | 句子合成结束。可选字段取决于服务端输出；`usage` 为该事件的完整 `payload.usage`。 |
| `finished` | `{ taskId: string; characters?: number; usage?: TtsUsage }` | 服务端确认任务结束；此时本地任务状态已清理。`usage` 为完整 `payload.usage`。 |
| `failed` | `DashScopeError` | 任务失败、连接错误、协议错误或任务确认超时。 |
| `error` | `DashScopeError` | 失败路径也会触发此事件，通常与 `failed` 代表同一次失败。 |
| `close` | `{ code: number; reason: string }` | 底层连接关闭通知，不等同于任务成功。 |
| `event` | `TtsServerEvent` | 原始服务端 JSON 消息，不包含二进制音频。 |

同一次失败通常会触发 `failed` 和 `error`，不要将两者当作两次独立失败重复处理。显式 `close()` 不主动发出这两类失败事件，但会拒绝正在等待的 Promise。

### 结果字段（TtsWord、TtsServerEvent）

`TtsWord` 的字段如下。时间戳和文本索引由服务端提供，SDK 不换算单位或补齐缺失值。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `text` | `string` | 当前字或词的文本。 |
| `begin_index`、`end_index` | `number`，可选 | 文本起止索引。 |
| `begin_time`、`end_time` | `number`，可选 | 音频起止时间，单位以模型协议为准。 |

`TtsServerEvent` 的结构如下：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `header.task_id` | `string` | 任务 ID。 |
| `header.event` | `'task-started' \| 'result-generated' \| 'task-finished' \| 'task-failed'` | 服务端事件类型。 |
| `header.attributes` | `Record<string, unknown>`，可选 | 附加信息。 |
| `header.error_code`、`header.error_message` | `string`，可选 | 失败信息。 |
| `payload.output.type` | `'sentence-begin' \| 'sentence-synthesis' \| 'sentence-end'`，可选 | 句子事件类型。 |
| `payload.output.original_text` | `string`，可选 | 原始文本。 |
| `payload.output.sentence.index` | `number`，可选 | 句子序号。 |
| `payload.output.sentence.words` | `TtsWord[]`，可选 | 字级时间戳。 |
| `payload.usage` | `TtsUsage`，可选 | 服务端返回的用量，可能包含 `characters`、`input_tokens`、`output_tokens`、`total_tokens`，字段以服务端返回为准；SDK 不计算累计值。 |

`payload`、`output`、`sentence` 均可能缺失。`sentence-synthesis` 没有单独的友好事件，可通过 `event` 访问。

## 示例代码：一次性合成

保存为 `tts-once.mjs`，运行 `node tts-once.mjs`。示例显式指定 MP3 格式，在任务成功后写入文件。

```js
import { writeFile } from 'node:fs/promises'
import { SpeechSynthesizer } from 'dashscope-sdk-nodejs/tts'

async function main() {
  const synth = new SpeechSynthesizer({
    apiKey: process.env.DASHSCOPE_API_KEY,
    workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
    // 服务域名：切换地域或使用业务空间专属域名时修改此处，例如 dashscope-intl.aliyuncs.com
    baseUrl: 'dashscope.aliyuncs.com',
    model: 'qwen-audio-3.1-tts-flash',
    voice: 'longanhuan_v3.1',
    format: 'mp3',
    sampleRate: 24000,
  })
  synth.on('error', (err) => console.error('[SDK]', err.code, err.requestId, err.taskId))

  try {
    const audio = await synth.synthesize('你好，欢迎使用 Qwen Audio。')
    await writeFile('output-tts.mp3', audio)
    console.log('合成完成，字节数：', audio.length)
  } finally {
    synth.close()
  }
}

main().catch((err) => {
  console.error('调用失败：', err.name, err.code, err.requestId, err.taskId)
  process.exitCode = 1
})
```

## 示例代码：流式输入与音频回调

保存为 `tts-streaming.mjs`，运行 `node tts-streaming.mjs`。示例在 `audio` 回调中观察实时音频块，在 `end()` 成功后写入完整文件。对接播放设备时，可将 `audio` 交给应用自身的播放队列。

```js
import { writeFile } from 'node:fs/promises'
import { setTimeout as sleep } from 'node:timers/promises'
import { SpeechSynthesizer } from 'dashscope-sdk-nodejs/tts'

async function main() {
  const synth = new SpeechSynthesizer({
    apiKey: process.env.DASHSCOPE_API_KEY,
    workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
    // 服务域名：切换地域或使用业务空间专属域名时修改此处，例如 dashscope-intl.aliyuncs.com
    baseUrl: 'dashscope.aliyuncs.com',
    model: 'qwen-audio-3.1-tts-flash',
    voice: 'longanhuan_v3.1',
    format: 'mp3',
    sampleRate: 24000,
    wordTimestampEnabled: true,
  })
  synth.on('audio', (chunk) => console.log('收到音频块：', chunk.length))
  synth.on('sentenceEnd', ({ index, text, words }) => {
    console.log('句子：', index, text, '时间戳：', words)
  })
  synth.on('error', (err) => console.error('[SDK]', err.code, err.requestId, err.taskId))

  try {
    await synth.begin()
    for (const text of ['白日依山尽，', '黄河入海流。']) {
      synth.sendText(text)
      await sleep(100)
    }
    const audio = await synth.end()
    await writeFile('output-tts-stream.mp3', audio)
    console.log('流式合成完成，字节数：', audio.length)
  } finally {
    synth.close()
  }
}

main().catch((err) => {
  console.error('调用失败：', err.name, err.code, err.requestId, err.taskId)
  process.exitCode = 1
})
```

## 错误处理（DashScopeError）

**导入路径**：`dashscope-sdk-nodejs` 或 `dashscope-sdk-nodejs/tts`。

SDK 自身的配置、网络、协议和任务错误通常使用 `DashScopeError`，继承自 `Error`。应用自行抛出的错误或监听器异常不一定是该类型。

**重要**：建议日志仅记录错误名、错误码、请求 ID 和任务 ID。错误 `message`、`raw`、`cause` 或完整错误对象可能包含签名 URL 和业务内容，记录前须脱敏。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `name` | `string` | 值为 `DashScopeError`。 |
| `message` | `string` | 错误描述。 |
| `code` | `string`，可选 | SDK 错误码或服务端错误码。 |
| `requestId` | `string`，可选 | 相关请求 ID，不保证所有错误均携带。 |
| `taskId` | `string`，可选 | 相关任务 ID，不保证所有错误均携带。 |
| `fatal` | `boolean` | SDK 对失败严重性的提示，不表示会自动重试或重连。 |
| `raw` | `unknown`，可选 | 原始错误数据，可能包含文本、音频地址或其他敏感信息。 |
| `cause` | `unknown`，可选 | 底层错误原因。 |

### 常见错误

| 错误码 | 含义 | 建议处理 |
| --- | --- | --- |
| `invalid_request_error` | 参数、状态或调用顺序不合法 | 修正参数或生命周期，不盲目重试。 |
| `timeout` | WebSocket 建连超时 | 排查网络，确认任务是否已在服务端提交成功。 |
| `task_timeout` | 等待 `task-started` 或 `task-finished` 确认超时 | SDK 会清理当前任务；业务决定是否重新启动。 |
| `network_error`、`connection_error` | 网络或连接失败 | 检查网络和服务可用性；不是所有连接错误都保证携带 code。 |
| `connection_closed` | 连接在任务结束前关闭 | 检查关闭码与错误原因。 |
| `protocol_error` | 收到无法解析或不符合当前协议的消息 | 检查地址和模型协议，保留脱敏诊断信息。 |
| `cancelled` | 应用显式 `close()` 导致取消 | 根据业务意图处理，通常无需告警重试。 |
| 服务端错误码 | 鉴权、配额、参数、服务端故障等 | 按服务端错误说明处理，提供请求 ID 便于排查。 |

**重要**：SDK 不自动重连或重试。不要仅凭 `fatal` 判断能否安全重试；重新提交合成任务可能重复计费。

## 使用限制与资源释放

| 场景 | 要求 |
| --- | --- |
| 一次性合成 | 单次文本不超过 20000，不自动拆分长文本；异常路径调用 `close()`。 |
| 流式输入 | 先等待 `begin()`，按片段上限发送，两次发送间隔小于 23 秒，最后等待 `end()`；异常路径调用 `close()`。 |
| 内存与背压 | SDK 缓存完整任务音频，`end()` 一次性返回。应用控制任务大小与发送节奏。 |
| 超时与取消 | 不支持 `AbortSignal`。`cancel()` 请求服务端停止合成，`close()` 本地立即取消。 |
| 诊断与隐私 | 日志保留错误码、请求 ID、任务 ID 即可；按需脱敏 `raw`、文本与音频内容。 |
