# Qwen Audio 实时语音识别 Node.js SDK

本文介绍如何通过 `dashscope-sdk-nodejs` 调用 Qwen Audio 实时语音识别服务，以及 `RecognitionClient` 的参数、方法、事件与示例代码。

**适用版本**：SDK `0.1.0`。

其他能力的接口文档：[语音合成](./dashscope-sdk-nodejs语音合成文档.md)、[录音文件转写](./dashscope-sdk-nodejs录音文件转写文档.md)、[实时语音对话](./dashscope-sdk-nodejs实时语音对话文档.md)。

## 前提条件

- 已开通所使用的模型服务，并取得对应地域的 API Key；按需准备业务空间 ID。
- 已安装 Node.js 18 或以上版本。此 SDK 是服务端 SDK，不支持在浏览器中直接使用。
- 实际服务调用可能产生费用。模型、可用地域、配额及参数能力以对应服务文档为准。
- 将 API Key 设置为环境变量 `DASHSCOPE_API_KEY`，或通过客户端构造参数传入。按需设置 `DASHSCOPE_WORKSPACE_ID`。

**重要**：不要将 API Key 写入前端代码、日志或源码仓库。SDK 会读取进程环境变量，但不会自动加载 `.env` 文件；如使用 `.env`，请由应用自行加载。

## 安装与导入

SDK 以本地安装包形式分发，不发布到公开 npm 仓库。从发布包的 `sdk/` 目录取得 `dashscope-sdk-nodejs-0.1.0.tgz`，放入业务项目（例如 `vendor/` 目录）后安装：

```bash
npm install ./vendor/dashscope-sdk-nodejs-0.1.0.tgz
```

安装后，`package.json` 中的依赖记录为 `file:vendor/dashscope-sdk-nodejs-0.1.0.tgz`。请将该 `.tgz` 文件随项目纳入版本管理或内部制品库，以便 CI 和其他成员复现安装。运行时依赖 `ws` 仍从项目配置的 npm 源安装。

ESM 和 TypeScript 可从子路径或主入口导入：

```ts
import { RecognitionClient, DashScopeError } from 'dashscope-sdk-nodejs/asr'
```

CommonJS 可使用 `require`：

```js
const { RecognitionClient } = require('dashscope-sdk-nodejs/asr')
```

下文完整示例使用 ESM，保存为对应的 `.mjs` 文件后运行。TypeScript 代码中的 `?` 表示可选参数或字段，`Promise<T>` 表示异步返回 `T`。

## 接口地址

SDK 默认连接 `dashscope.aliyuncs.com`。实时语音识别使用 WebSocket 地址 `wss://{host}/api-ws/v1/inference`，`{host}` 由 `baseUrl` 决定：只给域名时协议与路径由 SDK 补全。切换地域或改用业务空间专属域名，把 `baseUrl` 换成下表中的域名即可。

| 场景 | `baseUrl` 取值 |
| --- | --- |
| 华北2（北京）公共域名 | 省略，或 `dashscope.aliyuncs.com` |
| 新加坡公共域名 | `dashscope-intl.aliyuncs.com` |
| 华北2（北京）业务空间专属域名 | `{WorkspaceId}.cn-beijing.maas.aliyuncs.com` |
| 新加坡业务空间专属域名 | `{WorkspaceId}.ap-southeast-1.maas.aliyuncs.com` |

**重要**：不同地域的凭据和模型可用性可能不同。切换域名时，请同时核对 API Key、业务空间和模型。`workspaceId` 只用于生成 `X-DashScope-WorkSpace` 请求头，不会改变域名；使用业务空间专属域名须自行写入 `baseUrl`。

## 通用配置（BaseClientOptions）

`RecognitionOptions` 继承以下通用参数。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `apiKey` | `string` | 条件必填 | 显式传入的 API Key 优先；省略时读取 `DASHSCOPE_API_KEY`。两者均未提供时构造失败。 |
| `workspaceId` | `string` | 否 | 省略时读取 `DASHSCOPE_WORKSPACE_ID`。提供非空值时附带 `X-DashScope-WorkSpace` 请求头，不改变域名。 |
| `baseUrl` | `string` | 否 | 服务地址，默认 `dashscope.aliyuncs.com`。可只给域名，SDK 补全 `wss://` 与 `/api-ws/v1/inference`；已带路径的完整地址原样使用，可用于自定义网关。 |
| `headers` | `Record<string, string>` | 否 | 额外请求头。请避免重复设置鉴权头或业务空间头；显式提供的同名 `Authorization` 可以覆盖默认鉴权值。 |
| `onTrace` | `(event: ClientTraceEvent) => void \| Promise<void>` | 否 | 传输事件回调，记录连接、上下行消息和错误。回调异常不影响请求；URL 和业务数据须按需脱敏，字段见[接入文档](./dashscope-sdk-nodejs接入文档.md)。 |

`workspaceId` 的非空值须是由字母、数字或连字符组成的 1–63 字符 DNS label，不能以连字符开头或结尾。传空字符串表示显式不使用业务空间，不再读取环境变量中的业务空间 ID。

设置 `baseUrl` 不会绕过 API Key 与业务空间参数的构造期校验。非字符串 `baseUrl`、无法解析的地址或不受支持的协议（仅接受 `http`、`https`、`ws`、`wss` 或不带协议的域名）均在构造时抛出 `invalid_request_error`。

## 事件监听

`RecognitionClient` 支持以下方法。

| 方法 | 参数 | 返回值 | 说明 |
| --- | --- | --- | --- |
| `on(event, listener)` | 事件名、监听函数 | `this` | 持续监听事件。事件名与负载在 TypeScript 中有类型提示。 |
| `once(event, listener)` | 事件名、监听函数 | `this` | 仅监听一次。 |
| `off(event, listener?)` | 事件名、可选监听函数 | `this` | 提供函数时移除该监听；省略时移除该事件的全部监听。 |
| `removeAllListeners()` | 无 | `this` | 移除全部事件的监听。 |

**重要**：在启动任务前注册监听器，使用 `try/catch/finally` 处理异步调用失败并释放资源。未注册 `error` 监听器时，SDK 会通过 `console.warn` 输出错误消息；建议注册监听器并对日志脱敏。

监听器的异常由应用负责处理。SDK 不会等待异步监听器返回的 Promise。

## RecognitionClient

**导入路径**：`dashscope-sdk-nodejs/asr`，也可从主入口导入。

客户端流式发送音频二进制帧，服务端通过 JSON 消息返回中间识别结果和最终句子。

**任务流程**：`start()` → 收到 `task-started` → 多次 `sendAudio()` → `finish()` → 收到 `task-finished` → 关闭连接。

一个实例同一时间只运行一个任务；任务结束后可再次调用 `start()`。SDK 不读取麦克风、不自动重采样、不聚合最终文本，也不自动节流音频发送。

### 构造方法

```ts
new RecognitionClient(options?: RecognitionOptions)
```

### RecognitionOptions

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `model` | `string` | 否 | SDK 默认 `qwen-audio-3.1-asr-flash-streaming`。 |
| `format` | `RecognitionAudioFormat` | 否 | SDK 默认 `pcm`。类型包括 `pcm`、`wav`、`mp3`、`opus`、`speex`、`aac`、`amr`，不保证当前模型支持所有编码。 |
| `sampleRate` | `number` | 否 | SDK 默认 16000 Hz。音频实际采样率必须与请求参数一致。 |
| `vocabularyId` | `string` | 否 | 热词列表 ID，须使用支持热词的模型。 |
| `disfluencyRemovalEnabled` | `boolean` | 否 | 是否移除语气词。 |
| `languageHints` | `string[]` | 否 | 语种提示。 |
| `semanticPunctuationEnabled` | `boolean` | 否 | 语义断句开关。参数约定默认 `false`，使用 VAD 断句。 |
| `maxSentenceSilence` | `number` | 否 | VAD 断句静音阈值，单位 ms。Qwen Audio 流式识别的取值范围为 `[200,6000]`，服务端默认 800。 |
| `multiThresholdModeEnabled` | `boolean` | 否 | 多阈值模式开关。 |
| `punctuationPredictionEnabled` | `boolean` | 否 | 标点预测开关，参数约定默认 `true`。 |
| `heartbeat` | `boolean` | 否 | 向服务端透传心跳相关开关，不代表 SDK 自动发送心跳音频。 |
| `inverseTextNormalizationEnabled` | `boolean` | 否 | 逆文本正则化开关，参数约定默认 `true`。 |
| `context` | `AsrContextMessage[]` | 否 | 识别上下文，写入 `run-task` 的 `input.context`，用于提供背景文本和专有名词；省略时 `input` 为空对象。须为数组，否则构造时抛出参数错误。 |
| `parameters` | `Partial<RecognitionParameters>` | 否 | 扩展服务端参数，包括 `vad_model`。 |
| `dataInspection` | `'enable' \| 'disable'` | 否 | 数据合规检测请求头；省略时不发送。 |
| `connectTimeoutMs` | `number` | 否 | 建连超时，默认 10000 ms；请设置正数，`0` 不表示禁用。 |
| `taskTimeoutMs` | `number` | 否 | 分别等待 `task-started`、`task-finished` 的超时，默认 60000 ms；`0` 禁用。须为有限非负数，不限制整个音频流时长。 |

以上参数还继承通用配置。除 `model`、`format`、`sampleRate` 和超时默认值外，其他选项省略时通常不写入请求；参数约定的默认值和能力由模型服务决定。

### 识别上下文（AsrContextMessage）

```ts
interface AsrContextMessage {
  role: 'user' | 'assistant'
  content: Array<{ type: 'input_text' | 'text'; text: string; [key: string]: unknown }>
}
```

服务端对上下文的限制：每种角色最多 5 条，文本总长度少于 400 字符，`user` 消息排在 `assistant` 消息之前。SDK 只校验数组类型，其余规则由服务端判定。

```ts
const asr = new RecognitionClient({
  context: [{ role: 'user', content: [{ type: 'input_text', text: '会议主题：Qwen Audio 发布会' }] }],
})
```

### 扩展参数（RecognitionParameters）

`parameters` 使用服务端的 snake_case 字段名。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `vad_model` | `'near_meeting_16k' \| 'far_field_meeting_16k'` | 否 | 近场 VAD 或远场 VAD，服务端默认 `far_field_meeting_16k`。通过 `parameters` 设置；参见 [官方客户端事件文档](https://help.aliyun.com/zh/model-studio/qwen-asr-message-client-events)。 |
| `format`、`sample_rate` | `RecognitionAudioFormat`、`number` | 否 | 可覆盖顶层格式和采样率；不建议重复配置。 |
| `vocabulary_id` | `string` | 否 | 热词列表 ID。 |
| `language_hints` | `string[]` | 否 | 语种提示。 |
| `disfluency_removal_enabled` | `boolean` | 否 | 语气词过滤开关。 |
| `semantic_punctuation_enabled` | `boolean` | 否 | 语义断句开关。 |
| `max_sentence_silence` | `number` | 否 | VAD 静音阈值。 |
| `multi_threshold_mode_enabled` | `boolean` | 否 | 多阈值模式开关。 |
| `punctuation_prediction_enabled` | `boolean` | 否 | 标点预测开关。 |
| `heartbeat` | `boolean` | 否 | 心跳相关开关。 |
| `inverse_text_normalization_enabled` | `boolean` | 否 | 逆文本正则化开关。 |
| 其他字段 | `unknown` | 否 | 按服务端协议透传。 |

完整的 `RecognitionParameters` 类型要求 `format` 和 `sample_rate`，但构造选项接受 `Partial<RecognitionParameters>`，因此表中均为可选。

**参数优先级**：`parameters.format`、`parameters.sample_rate` 覆盖顶层 `format`、`sampleRate`；其余顶层显式选项则覆盖 `parameters` 中对应字段。为避免歧义，同一参数只在一处设置。

### 属性

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `isRunning` | `boolean`，只读 | 是否有任务运行，包括建连和等待结束阶段。必须等待 `start()` 完成后才可发送音频。 |

### start() - 开启识别任务

```ts
start(): Promise<void>
```

**返回值**：收到 `task-started` 后兑现。已有任务运行时拒绝；每次启动建立新连接及任务 ID。

### sendAudio() - 发送音频

```ts
sendAudio(audio: Buffer | Uint8Array): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `audio` | `Buffer \| Uint8Array` | 是 | 当前音频片段。编码、采样率及声道须满足所选模型要求，并与请求参数一致。 |

**返回值**：无。已启动任务中的空数据被忽略。SDK 直接发送音频字节，不转换格式、不验证文件头、不做背压控制。

对于 16 kHz、16-bit、单声道原始 PCM，100 ms 为 3200 字节。不要将 WAV 容器文件按原始 PCM 发送。

### updateContext() - 任务中更新上下文

```ts
updateContext(context: AsrContextMessage[]): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `context` | `AsrContextMessage[]` | 是 | 新的识别上下文。 |

**返回值**：无。发送 `continue-task`，负载为 `{ input: { context } }`。须在 `start()` 兑现后、`finish()` 之前调用，否则抛出参数错误。是否支持中途更新由所选模型决定；不支持时服务端可能忽略或返回 `task-failed`。

### finish() - 结束识别

```ts
finish(): Promise<void>
```

发送一次 `finish-task` 并等待服务端 `task-finished`，随后清理状态并关闭连接。

**返回值**：无识别文本。文本通过 `result` 或 `sentenceEnd` 事件获得。等待结束期间重复调用返回同一 Promise。

### close() - 本地关闭连接

```ts
close(code?: number, reason?: string): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `code` | `number` | 否 | WebSocket 关闭码，默认 1000。 |
| `reason` | `string` | 否 | 关闭原因，默认 `client closing`；须满足 WebSocket 关闭帧限制。 |

关闭连接后立即清理本地任务，并以 `code: 'cancelled'` 的错误拒绝启动或结束等待者。需要正常处理尾部音频时应先等待 `finish()`；直接 `close()` 不是正常提交。OPEN 状态下非法关闭码（例如 1006）或超过 123 字节的 UTF-8 原因会同步抛出底层异常；任务和连接保持原状，修正参数后可再次关闭。

### 事件（RecognitionEvents）

| 事件 | 负载类型 | 说明 |
| --- | --- | --- |
| `started` | `{ taskId: string }` | 服务端确认任务已启动。 |
| `result` | `RecognitionSentence` | 中间或最终句子，已过滤 `heartbeat: true` 的结果。 |
| `sentenceEnd` | `RecognitionSentence` | 最终句子，`sentence_end === true`。通常同一条结果先触发 `result`，再触发此事件。 |
| `finished` | `{ taskId: string; duration?: number; usage?: RecognitionUsage }` | 服务端确认任务结束；`duration` 与 `usage` 原样来自服务端 `payload.usage`。 |
| `failed` | `DashScopeError` | 任务、连接、协议或超时失败。 |
| `error` | `DashScopeError` | 失败路径也会触发；通常与 `failed` 为同一次失败。 |
| `close` | `{ code: number; reason: string }` | 底层连接关闭。 |
| `event` | `RecognitionServerEvent` | 原始 JSON 事件，包含被友好结果事件过滤的心跳信息。 |

如果只需最终文本，监听 `sentenceEnd` 即可；不要同时从 `result` 的最终结果和 `sentenceEnd` 重复追加同一句文字。

### 结果字段（RecognitionSentence）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `text` | `string` | 识别文本。 |
| `sentence_end` | `boolean` | `false` 为中间结果，`true` 为最终结果。 |
| `sentence_id` | `number`，可选 | 句子序号，同一句的中间结果与最终结果相同。 |
| `sentence_begin` | `boolean`，可选 | 是否为该句的第一条结果。 |
| `begin_time` | `number`，可选 | 句子起始时间。 |
| `end_time` | `number \| null`，可选 | 句子结束时间；中间结果可能没有确定的结束时间。 |
| `heartbeat` | `boolean`，可选 | 心跳标记。 |
| `emo_tag` | `'positive' \| 'negative' \| 'neutral'`，可选 | 服务端情感标签。 |
| `emo_confidence` | `number`，可选 | 情感置信度。 |
| `words` | `RecognitionWord[]`，可选 | 字级结果。 |
| `channel_id` | `number`，可选 | 音轨索引。 |
| `speaker_id` | `number \| null`，可选 | 说话人 ID。 |
| `stash` | `{ sentence_id: number; text: string; begin_time: number; current_time: number; words: RecognitionWord[] }`，可选 | 尚未确定的下一句暂存结果。 |

`RecognitionWord` 包含可选字段 `begin_time: number`、`end_time: number`、`text: string`、`punctuation: string`、`fixed: boolean`、`speaker_id: number | null`。时间戳单位与可用字段以模型协议为准，SDK 原样返回。

### 原始事件（RecognitionServerEvent）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `header.task_id` | `string` | 任务 ID。 |
| `header.event` | `'task-started' \| 'result-generated' \| 'task-finished' \| 'task-failed'` | 事件类型。 |
| `header.attributes` | `Record<string, unknown>`，可选 | 附加信息。 |
| `header.error_code`、`header.error_message` | `string`，可选 | 失败信息。 |
| `payload.output.sentence` | `RecognitionSentence`，可选 | 识别句子。 |
| `payload.output.text`、`payload.output.request_id` | `string`，可选 | 服务端返回的输出文本与请求 ID。 |
| `payload.usage` | `RecognitionUsage \| null`，可选 | 服务端返回的用量，可能包含 `duration`、`input_tokens`、`output_tokens`、`total_tokens`，字段以服务端返回为准。 |

`payload`、`output`、`sentence` 均可能缺失。

## 示例代码：PCM 文件流式识别

先准备 16 kHz、16-bit、单声道原始 PCM：

```bash
ffmpeg -i input.mp3 -f s16le -ac 1 -ar 16000 input.pcm
```

保存为 `asr-realtime.mjs`，运行 `node asr-realtime.mjs ./input.pcm`。示例使用近场 VAD；远场场景将 `vad_model` 改为 `far_field_meeting_16k`，并核对模型支持。

```js
import { readFile } from 'node:fs/promises'
import { setTimeout as sleep } from 'node:timers/promises'
import { RecognitionClient } from 'dashscope-sdk-nodejs/asr'

async function main() {
  const input = process.argv[2]
  if (!input) throw new Error('用法：node asr-realtime.mjs <input.pcm>')
  const pcm = await readFile(input)
  if (!pcm.length || pcm.length % 2) {
    throw new Error('PCM 必须非空且包含完整的 16-bit 采样')
  }

  const asr = new RecognitionClient({
    apiKey: process.env.DASHSCOPE_API_KEY,
    workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
    // 服务域名：切换地域或使用业务空间专属域名时修改此处，例如 dashscope-intl.aliyuncs.com
    baseUrl: 'dashscope.aliyuncs.com',
    model: 'qwen-audio-3.1-asr-flash-streaming',
    format: 'pcm',
    sampleRate: 16000,
    parameters: { vad_model: 'near_meeting_16k' },
  })
  const sentences = []
  asr.on('sentenceEnd', (sentence) => {
    sentences.push(sentence.text)
    console.log('最终句子：', sentence.text)
  })
  asr.on('finished', ({ taskId, duration }) => console.log('任务结束：', taskId, duration))
  asr.on('error', (err) => console.error('[SDK]', err.code, err.requestId, err.taskId))

  try {
    await asr.start()
    for (let offset = 0; offset < pcm.length; offset += 3200) {
      asr.sendAudio(pcm.subarray(offset, offset + 3200))
      await sleep(100)
    }
    await asr.finish()
    console.log('完整文本：', sentences.join(''))
  } finally {
    asr.close()
  }
}

main().catch((err) => {
  console.error('调用失败：', err.name, err.code, err.requestId, err.taskId)
  process.exitCode = 1
})
```

## 错误处理（DashScopeError）

**导入路径**：`dashscope-sdk-nodejs` 或 `dashscope-sdk-nodejs/asr`。

SDK 自身的配置、网络、协议和任务错误通常使用 `DashScopeError`，继承自 `Error`。应用自行抛出的错误或监听器异常不一定是该类型。

**重要**：建议日志仅记录错误名、错误码、请求 ID 和任务 ID。错误 `message`、`raw`、`cause` 或完整错误对象可能包含签名 URL 和业务内容，记录前须脱敏。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `name` | `string` | 值为 `DashScopeError`。 |
| `message` | `string` | 错误描述。 |
| `code` | `string`，可选 | SDK 错误码或服务端错误码。 |
| `requestId` | `string`，可选 | 相关请求 ID，不保证所有错误均携带。 |
| `taskId` | `string`，可选 | 相关任务 ID，不保证所有错误均携带。 |
| `fatal` | `boolean` | SDK 对失败严重性的提示，不表示会自动重试或重连。 |
| `raw` | `unknown`，可选 | 原始错误数据，可能包含文本、音频地址或其他敏感信息。 |
| `cause` | `unknown`，可选 | 底层错误原因。 |

### 常见错误

| 错误码 | 含义 | 建议处理 |
| --- | --- | --- |
| `invalid_request_error` | 参数、状态或调用顺序不合法 | 修正参数或生命周期，不盲目重试。 |
| `timeout` | WebSocket 建连超时 | 排查网络，确认任务是否已在服务端提交成功。 |
| `task_timeout` | 等待 `task-started` 或 `task-finished` 确认超时 | SDK 会清理当前任务；业务决定是否重新启动。 |
| `network_error`、`connection_error` | 网络或连接失败 | 检查网络和服务可用性；不是所有连接错误都保证携带 code。 |
| `connection_closed` | 连接在任务结束前关闭 | 检查关闭码与错误原因。 |
| `protocol_error` | 收到无法解析或不符合当前协议的消息 | 检查地址和模型协议，保留脱敏诊断信息。 |
| `cancelled` | 应用显式 `close()` 导致取消 | 根据业务意图处理，通常无需告警重试。 |
| 服务端错误码 | 鉴权、配额、参数、服务端故障等 | 按服务端错误说明处理，提供请求 ID 便于排查。 |

**重要**：SDK 不自动重连或重试。不要仅凭 `fatal` 判断能否安全重试；重新提交识别任务可能重复计费。

## 使用限制与资源释放

| 场景 | 要求 |
| --- | --- |
| 任务生命周期 | 先等待 `start()`，再发送音频，正常结束等待 `finish()`；异常路径调用 `close()`。 |
| 音频格式 | 编码、采样率、声道须与请求参数一致；SDK 不重采样、不解析容器格式。 |
| 发送节奏 | 按实时节奏发送，16 kHz 单声道 PCM 每 100 ms 约 3200 字节；SDK 不提供自动背压。 |
| 文本聚合 | SDK 不聚合最终文本，由应用从 `sentenceEnd` 自行拼接。 |
| 超时与取消 | 不支持 `AbortSignal`。`close()` 为本地取消，不是正常提交。 |
| 诊断与隐私 | 日志保留错误码、请求 ID、任务 ID 即可；按需脱敏 `raw`、识别文本与音频内容。 |
