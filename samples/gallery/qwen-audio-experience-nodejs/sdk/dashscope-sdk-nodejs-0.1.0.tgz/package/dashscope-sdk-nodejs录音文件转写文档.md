# Qwen Audio 录音文件转写 Node.js SDK

本文介绍如何通过 `dashscope-sdk-nodejs` 调用录音文件转写服务，以及 `TranscriptionClient` 的参数、方法、结果结构与示例代码。

**适用版本**：SDK `0.1.0`。

其他能力的接口文档：[语音合成](./dashscope-sdk-nodejs语音合成文档.md)、[实时语音识别](./dashscope-sdk-nodejs实时语音识别文档.md)、[实时语音对话](./dashscope-sdk-nodejs实时语音对话文档.md)。

## 前提条件

- 已开通所使用的模型服务，并取得对应地域的 API Key；按需准备业务空间 ID。
- 已安装 Node.js 18 或以上版本。此 SDK 是服务端 SDK，不支持在浏览器中直接使用。
- 已准备服务端可访问的音频 URL。SDK 不上传本地文件。
- 实际服务调用可能产生费用。模型、可用地域、配额及参数能力以对应服务文档为准。
- 将 API Key 设置为环境变量 `DASHSCOPE_API_KEY`，或通过客户端构造参数传入。按需设置 `DASHSCOPE_WORKSPACE_ID`。

**重要**：不要将 API Key 写入前端代码、日志或源码仓库。SDK 会读取进程环境变量，但不会自动加载 `.env` 文件；如使用 `.env`，请由应用自行加载。

## 安装与导入

SDK 以本地安装包形式分发，不发布到公开 npm 仓库。从发布包的 `sdk/` 目录取得 `dashscope-sdk-nodejs-0.1.0.tgz`，放入业务项目（例如 `vendor/` 目录）后安装：

```bash
npm install ./vendor/dashscope-sdk-nodejs-0.1.0.tgz
```

安装后，`package.json` 中的依赖记录为 `file:vendor/dashscope-sdk-nodejs-0.1.0.tgz`。请将该 `.tgz` 文件随项目纳入版本管理或内部制品库，以便 CI 和其他成员复现安装。运行时依赖 `ws` 仍从项目配置的 npm 源安装。

ESM 和 TypeScript 可从子路径或主入口导入：

```ts
import { TranscriptionClient, DashScopeError } from 'dashscope-sdk-nodejs/asr'
```

CommonJS 可使用 `require`：

```js
const { TranscriptionClient } = require('dashscope-sdk-nodejs/asr')
```

下文完整示例使用 ESM，保存为对应的 `.mjs` 文件后运行。TypeScript 代码中的 `?` 表示可选参数或字段，`Promise<T>` 表示异步返回 `T`。

## 接口地址

SDK 默认连接 `dashscope.aliyuncs.com`。`{host}` 由 `baseUrl` 决定：只给域名时协议与路径由 SDK 补全。切换地域或改用业务空间专属域名，把 `baseUrl` 换成下表中的域名即可。

| 场景 | `baseUrl` 取值 |
| --- | --- |
| 华北2（北京）公共域名 | 省略，或 `dashscope.aliyuncs.com` |
| 新加坡公共域名 | `dashscope-intl.aliyuncs.com` |
| 华北2（北京）业务空间专属域名 | `{WorkspaceId}.cn-beijing.maas.aliyuncs.com` |
| 新加坡业务空间专属域名 | `{WorkspaceId}.ap-southeast-1.maas.aliyuncs.com` |

### 接口路径

| 用途 | 地址 |
| --- | --- |
| 提交转写任务 | `https://{host}/api/v1/services/audio/asr/transcription` |
| 查询任务状态 | `https://{host}/api/v1/tasks/{taskId}` |

`{host}` 替换为上表中的域名。SDK 自动编码任务查询路径中的任务 ID。

**重要**：不同地域的凭据和模型可用性可能不同。切换域名时，请同时核对 API Key、业务空间和模型。`workspaceId` 只用于生成 `X-DashScope-WorkSpace` 请求头，不会改变域名；使用业务空间专属域名须自行写入 `baseUrl`。

## 通用配置（BaseClientOptions）

`TranscriptionOptions` 继承以下通用参数。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `apiKey` | `string` | 条件必填 | 显式传入的 API Key 优先；省略时读取 `DASHSCOPE_API_KEY`。两者均未提供时构造失败。 |
| `workspaceId` | `string` | 否 | 省略时读取 `DASHSCOPE_WORKSPACE_ID`。提供非空值时附带 `X-DashScope-WorkSpace` 请求头，不改变域名。 |
| `baseUrl` | `string` | 否 | 服务地址，默认 `dashscope.aliyuncs.com`。可只给域名，SDK 补全 `https://` 并在其后追加提交或查询路径。`baseUrl` 始终按前缀处理，不要传完整提交接口，否则会重复拼接路径。 |
| `headers` | `Record<string, string>` | 否 | 额外请求头。请避免重复设置鉴权头或业务空间头；显式提供的同名 `Authorization` 可以覆盖默认鉴权值。 |
| `onTrace` | `(event: ClientTraceEvent) => void \| Promise<void>` | 否 | HTTP 传输事件回调，记录请求、响应和错误。回调异常不影响请求；URL 和业务数据须按需脱敏，字段见[接入文档](./dashscope-sdk-nodejs接入文档.md)。 |

`workspaceId` 的非空值须是由字母、数字或连字符组成的 1–63 字符 DNS label，不能以连字符开头或结尾。传空字符串表示显式不使用业务空间，不再读取环境变量中的业务空间 ID。

设置 `baseUrl` 不会绕过 API Key 与业务空间参数的构造期校验。非字符串 `baseUrl`、无法解析的地址或不受支持的协议（仅接受 `http`、`https`、`ws`、`wss` 或不带协议的域名）均在构造时抛出 `invalid_request_error`。

## TranscriptionClient

**导入路径**：`dashscope-sdk-nodejs/asr`，也可从主入口导入。

适用于已录制的音频，通过服务端可访问的音频 URL 提交异步转写任务。SDK 不上传本地文件。

提供一站式 `transcribe()`，也可使用 `submitTask()` 和 `fetchTask()` 自行管理任务。此类不继承事件发射器，没有 `on()`、`close()` 或 `cancel()` 方法。

### 构造方法

```ts
new TranscriptionClient(options?: TranscriptionOptions)
```

### TranscriptionOptions

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `model` | `string` | 否 | 默认 `qwen-audio-3.1-asr-flash-filetrans`；可显式设置其他支持的文件转写模型。 |
| `pollIntervalMs` | `number` | 否 | 两次状态查询之间的间隔，默认 3000 ms。 |
| `pollTimeoutMs` | `number` | 否 | 轮询总超时，默认 600000 ms。须使用正数；`0` 会立即超时，不表示禁用。 |
| `requestTimeoutMs` | `number` | 否 | 单次 HTTP 请求超时，默认 30000 ms；`0` 禁用独立的单次超时，但轮询查询仍受总期限约束。 |

以上参数还继承通用配置。轮询期限从提交完成后开始，不包含提交请求和最终结果下载阶段；它不是整个 `transcribe()` 的总时限。轮询超时不代表服务端任务已经取消。

### submitTask() - 提交转写任务

```ts
submitTask(
  fileUrls: string | string[],
  parameters?: TranscriptionParameters,
  submitOpts?: TranscriptionSubmitOptions,
): Promise<{ taskId: string; taskStatus: string }>
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `fileUrls` | `string \| string[]` | 是 | 服务端可访问的音频 URL。接受非空、非空白字符串或任意非空字符串数组；数组各项均须为非空、非空白字符串。空数组、空/空白字符串及非字符串元素会在发送请求前抛出 `invalid_request_error`。文件数量支持由模型服务决定，SDK 不设数量上限。 |
| `parameters` | `TranscriptionParameters` | 否 | 转写参数。SDK 在省略时仍发送空对象 `{}`。 |
| `submitOpts` | `TranscriptionSubmitOptions` | 否 | 请求附加内容，目前为 `context`（`AsrContextMessage[]`），写入请求体 `input.context`；省略时不发送。须为数组，否则抛出参数错误。 |

SDK 将所选 `model` 和完整的 `input.file_urls` 透传给服务端；单字符串仅包装为数组。不去重、不裁剪 URL 字符串、不拆批，也不按模型在本地拦截文件数量。多文件及重复 URL 是否被接受以模型服务为准；服务端拒绝时保留其错误码、错误消息、请求 ID 和原始响应。

`AsrContextMessage` 的结构为 `{ role: 'user' | 'assistant'; content: Array<{ type: 'input_text' | 'text'; text: string }> }`。服务端限制每种角色最多 5 条、文本总长度少于 400 字符，`user` 消息排在 `assistant` 消息之前。

**返回值**：任务 ID `taskId` 和提交后的初始状态 `taskStatus`，不是最终转写结果。提交响应没有状态时 SDK 使用 `PENDING`。

### fetchTask() - 查询一次任务

```ts
fetchTask(taskId: string, requestTimeoutMs?: number): Promise<QueryTaskResponse>
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `taskId` | `string` | 是 | 已提交的任务 ID。 |
| `requestTimeoutMs` | `number` | 否 | 覆盖本次查询请求的超时；省略时使用构造配置，`0` 禁用本次独立超时。 |

**返回值**：原始查询响应 `QueryTaskResponse`。该方法只查询一次，不轮询、不自动下载结果。

### transcribe() - 一站式转写

```ts
transcribe(
  fileUrls: string | string[],
  parameters?: TranscriptionParameters,
  callOpts?: TranscribeCallOptions,
): Promise<TranscriptionJobResult>
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `fileUrls` | `string \| string[]` | 是 | 音频 URL，与 `submitTask()` 相同。 |
| `parameters` | `TranscriptionParameters` | 否 | 服务端转写参数。 |
| `callOpts` | `TranscribeCallOptions` | 否 | 调用配置，可设置 `context` 识别上下文（同 `submitTask()`）和 `onProgress` 进度回调。 |

**返回值**：SDK 聚合结果。内部提交、轮询至终态，并自动下载成功子任务的 `transcription_url`。

**失败处理**：

- 顶层任务状态为 `FAILED` 或 `CANCELED` 时，拒绝 Promise，错误码为 `task_failed`。
- 查询失败或轮询超时也会拒绝，不自动重试。
- 子任务失败保留在 `results` 中；结果下载失败或下载内容不是有效转写文档时，转换为 `subtaskStatus: 'FAILED'`、`code: 'DOWNLOAD_FAILED'`，不因此拒绝整个调用。`raw` 中保留服务端原始状态。
- 顶层 `taskStatus: 'SUCCEEDED'` 不保证每个聚合结果成功。必须逐项检查 `subtaskStatus`。

如只需要查询状态与下载链接，请使用 `submitTask()` 和 `fetchTask()` 自行轮询。

### 转写参数（TranscriptionParameters）

参数使用 snake_case 字段名，全部可选，按所选模型的支持情况配置。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `keep_dialect` | `boolean` | 否 | 保留方言，适用于 `qwen-audio-3.1-asr-flash-filetrans`。 |
| `vocabulary_id` | `string` | 否 | 预编译热词列表 ID。 |
| `vocabulary` | `Record<string, number>` | 否 | 即时热词与权重；参数约定权重为 `[1,5]` 或 50。 |
| `channel_id` | `number[]` | 否 | 音轨索引，参数约定默认 `[0]`；多音轨用量由服务计费规则决定。 |
| `special_word_filter` | `string \| Record<string, unknown>` | 否 | 敏感词过滤参数，可传 JSON 字符串或对象。 |
| `diarization_enabled` | `boolean` | 否 | 说话人分离，参数约定默认 `false`，仅适用于支持该能力的单声道场景。 |
| `speaker_count` | `number` | 否 | 说话人数量参考值，参数约定范围 `[2,100]`，需开启说话人分离。 |
| `language_hints` | `string[]` | 否 | 语种提示。 |
| 其他字段 | `unknown` | 否 | 服务端扩展参数。 |

SDK 不注入以上服务端默认值，也不验证全部模型兼容性和取值范围。

### 调用配置（TranscribeCallOptions）

```ts
interface TranscribeCallOptions {
  context?: AsrContextMessage[]
  onProgress?: (status: string, response: QueryTaskResponse) => void
}
```

`onProgress` 的参数如下：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `status` | `string` | 当前查询状态。服务端未返回时为 `UNKNOWN`。 |
| `response` | `QueryTaskResponse` | 当前查询的完整响应，可读取请求 ID 和任务指标。 |

每次成功查询都会回调，包括状态未变化和终态，不是仅在状态变化时触发。回调抛错会中止调用；SDK 不等待异步回调。

### 查询结果（QueryTaskResponse）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `request_id` | `string`，可选 | 当前查询请求 ID。 |
| `output.task_id` | `string` | 任务 ID。 |
| `output.task_status` | `string` | 任务状态，例如 `PENDING`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELED`。 |
| `output.submit_time`、`scheduled_time`、`end_time` | `string`，可选 | 服务端提交、调度与结束时间。三个字段均位于 `output` 下。 |
| `output.results` | `SubtaskResult[]`，可选 | 子任务结果。 |
| `output.task_metrics` | `{ TOTAL?: number; SUCCEEDED?: number; FAILED?: number }`，可选 | 子任务数量指标。 |
| `usage` | `RecognitionUsage`，可选 | 服务端用量，可能包含 `duration`、`input_tokens`、`output_tokens`、`total_tokens` 及其他扩展字段。 |

`SubtaskResult` 的字段如下：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `file_url` | `string`，可选 | 输入文件 URL。 |
| `transcription_url` | `string`，可选 | 结果 JSON 下载链接，通常有效期为 24 小时，请及时下载并按敏感数据保护。 |
| `subtask_status` | `string` | 子任务状态。 |
| `code`、`message` | `string`，可选 | 失败信息。 |

### 聚合结果（TranscriptionJobResult）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `taskId` | `string` | 任务 ID。 |
| `taskStatus` | `string` | 顶层任务终态。 |
| `results` | `FileTranscriptionResult[]` | 逐文件聚合结果，保持服务端子任务顺序。 |
| `usage` | `RecognitionUsage`，可选 | 原始用量，字段同 `QueryTaskResponse.usage`。 |
| `raw` | `QueryTaskResponse` | 最后一次查询响应，包含原始下载链接。 |

`FileTranscriptionResult` 的字段如下：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `fileUrl` | `string`，可选 | 输入文件 URL。 |
| `subtaskStatus` | `string` | 当前聚合项状态，包括下载失败转换得到的 `FAILED`。 |
| `transcription` | `TranscriptionDocument`，可选 | 下载并解析的结果文档。 |
| `text` | `string`，可选 | 便捷文本：优先采用每个音轨的整段文本，否则拼接句子；音轨之间用换行分隔。 |
| `code`、`message` | `string`，可选 | 子任务或下载失败信息。 |

聚合项没有 `transcriptionUrl` 字段，需要下载链接时读取 `raw.output.results`。下载结果时 SDK 不携带 API Key、业务空间头或自定义请求头。

SDK 对下载结果做边界校验：文档须为 JSON 对象，`transcripts` 须为数组；每个音轨须为对象且至少包含 `text` 或 `sentences`，`text` 须为字符串，`sentences` 须为数组且每句含字符串 `text`。允许 `transcripts: []`（无语音）、空文本和服务端附加字段。校验失败时该聚合项为 `DOWNLOAD_FAILED`，`message` 指出字段路径。SDK 不校验时间戳、词列表等其他元数据，应用使用这些字段前仍须自行检查。

### 转写文档（TranscriptionDocument）

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `file_url` | `string`，可选 | 输入文件 URL。 |
| `properties.audio_format` | `string`，可选 | 原始音频格式。 |
| `properties.channels` | `number[]`，可选 | 音轨列表。 |
| `properties.original_sampling_rate` | `number`，可选 | 原始采样率。 |
| `properties.original_duration_in_milliseconds` | `number`，可选 | 原始时长，单位 ms。 |
| `transcripts` | `TranscriptItem[]`，可选 | 各音轨转写内容。`transcribe()` 返回的成功聚合项已校验其为数组；无语音时可为空数组。 |

`properties` 本身也可缺失。嵌套类型如下：

| 类型 | 字段 | 说明 |
| --- | --- | --- |
| `TranscriptItem` | `channel_id?: number` | 音轨索引。 |
| `TranscriptItem` | `content_duration_in_milliseconds?: number` | 内容时长，单位 ms。 |
| `TranscriptItem` | `text?: string`、`sentences?: TranscriptSentence[]` | 整段文本及句子列表。 |
| `TranscriptSentence` | `begin_time?: number`、`end_time?: number`、`text?: string` | 句子时间及文本。 |
| `TranscriptSentence` | `sentence_id?: number`、`speaker_id?: number`、`words?: TranscriptWord[]` | 句子 ID、说话人 ID 和词列表。 |
| `TranscriptWord` | `begin_time?: number`、`end_time?: number`、`text?: string`、`punctuation?: string` | 词时间、文本和标点。 |

除显式标注毫秒的字段外，时间字段单位以模型协议为准，SDK 不进行换算。

## 示例代码：一站式文件转写

保存为 `asr-file.mjs`。将你有权使用、服务端可下载的音频地址放入 `AUDIO_URL` 环境变量，运行 `node asr-file.mjs`。不要向公共日志打印带签名的音频或结果 URL。

```js
import { writeFile } from 'node:fs/promises'
import { TranscriptionClient } from 'dashscope-sdk-nodejs/asr'

async function main() {
  const audioUrl = process.env.AUDIO_URL
  if (!audioUrl) throw new Error('请设置 AUDIO_URL 为服务端可访问的音频地址')

  const client = new TranscriptionClient({
    apiKey: process.env.DASHSCOPE_API_KEY,
    workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
    // 服务域名：切换地域或使用业务空间专属域名时修改此处，例如 dashscope-intl.aliyuncs.com
    baseUrl: 'dashscope.aliyuncs.com',
    model: 'qwen-audio-3.1-asr-flash-filetrans',
    pollIntervalMs: 2000,
    pollTimeoutMs: 600000,
  })
  const job = await client.transcribe(audioUrl, {}, {
    onProgress: (status, response) => {
      console.log('查询状态：', status, '请求 ID：', response.request_id)
    },
  })

  console.log('任务：', job.taskId, job.taskStatus)
  for (const [index, result] of job.results.entries()) {
    if (result.subtaskStatus !== 'SUCCEEDED') {
      console.error('子任务失败：', index, result.code, job.taskId)
      process.exitCode = 1
      continue
    }
    console.log('文本：', result.text)
    await writeFile(`transcription-${index}.json`, JSON.stringify(result.transcription, null, 2))
  }
}

main().catch((err) => {
  console.error('调用失败：', err.name, err.code, err.requestId, err.taskId)
  process.exitCode = 1
})
```

## 错误处理（DashScopeError）

**导入路径**：`dashscope-sdk-nodejs` 或 `dashscope-sdk-nodejs/asr`。

SDK 自身的配置、网络、协议和任务错误通常使用 `DashScopeError`，继承自 `Error`。应用自行抛出的错误或回调异常不一定是该类型。

**重要**：建议日志仅记录错误名、错误码、请求 ID 和任务 ID。错误 `message`、`raw`、`cause` 或完整错误对象可能包含签名 URL 和业务内容，记录前须脱敏。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `name` | `string` | 值为 `DashScopeError`。 |
| `message` | `string` | 错误描述。 |
| `code` | `string`，可选 | SDK 错误码或服务端错误码。 |
| `requestId` | `string`，可选 | 相关请求 ID，不保证所有错误均携带。 |
| `taskId` | `string`，可选 | 相关任务 ID，不保证所有错误均携带。 |
| `fatal` | `boolean` | SDK 对失败严重性的提示，不表示会自动重试或重连。 |
| `raw` | `unknown`，可选 | 原始错误数据，可能包含文本、音频地址或其他敏感信息。 |
| `cause` | `unknown`，可选 | 底层错误原因。 |

### 常见错误

| 错误码 | 含义 | 建议处理 |
| --- | --- | --- |
| `invalid_request_error` | 参数、状态或调用顺序不合法，例如未提供有效的音频 URL | 修正参数，不盲目重试。 |
| `timeout` | 单次 HTTP 请求超时 | 排查网络，确认任务是否已在服务端提交成功。 |
| `poll_timeout` | 轮询期限到达 | 保存任务 ID，后续可用 `fetchTask()` 查询；不表示服务端任务取消。 |
| `task_failed` | 顶层任务状态为 `FAILED` 或 `CANCELED` | 检查 `taskId` 和原始查询响应。 |
| `network_error`、`connection_error` | 网络或连接失败 | 检查网络和服务可用性；不是所有连接错误都保证携带 code。 |
| 服务端错误码或 HTTP 状态码 | 鉴权、配额、参数、服务端故障等 | 按服务端错误说明处理，提供请求 ID 便于排查。 |

`DOWNLOAD_FAILED` 是文件聚合项的结果码，不是 `transcribe()` 必然抛出的异常码。

**重要**：SDK 不自动重试。HTTP 错误没有会话连接可供关闭，`fatal: true` 也不代表任务已在服务端终止；重新提交任务可能重复计费。

## 使用限制与资源释放

| 场景 | 要求 |
| --- | --- |
| 输入方式 | 只接收服务端可访问的音频 URL，不上传本地文件。 |
| 失败分层 | 区分顶层任务失败、子任务失败和结果下载失败，逐项检查 `subtaskStatus`。 |
| 结果校验 | SDK 只校验文档结构及文本字段；使用时间戳、词列表等其他元数据前须自行检查。 |
| 文件数量 | 数量支持由模型服务决定，SDK 不设数量上限；非空 URL 数组完整透传，不去重或拆批。 |
| 结果时效 | `transcription_url` 通常 24 小时有效，请及时下载，并按敏感数据保护。 |
| 超时与取消 | 不支持 `AbortSignal`；轮询超时不取消服务端任务。 |
| 诊断与隐私 | 日志保留错误码、请求 ID、任务 ID 即可；不要打印带签名的音频或结果 URL。 |
