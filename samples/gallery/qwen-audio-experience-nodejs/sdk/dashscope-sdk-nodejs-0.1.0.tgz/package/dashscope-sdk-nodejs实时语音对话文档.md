# Qwen Audio 实时语音对话 Node.js SDK

本文介绍如何通过 `dashscope-sdk-nodejs` 调用 Qwen Audio 实时语音对话服务，以及 `RealtimeClient` 的参数、方法、事件与示例代码。

**适用版本**：SDK `0.1.0`。

其他能力的接口文档：[语音合成](./dashscope-sdk-nodejs语音合成文档.md)、[实时语音识别](./dashscope-sdk-nodejs实时语音识别文档.md)、[录音文件转写](./dashscope-sdk-nodejs录音文件转写文档.md)。

## 前提条件

- 已开通所使用的模型服务，并取得对应地域的 API Key；按需准备业务空间 ID。
- 已安装 Node.js 18 或以上版本。此 SDK 是服务端 SDK，不支持在浏览器中直接使用。
- 实际服务调用可能产生费用。模型、音色、可用地域、配额及参数能力以对应服务文档为准。
- 将 API Key 设置为环境变量 `DASHSCOPE_API_KEY`，或通过客户端构造参数传入。按需设置 `DASHSCOPE_WORKSPACE_ID`。

**重要**：不要将 API Key 写入前端代码、日志或源码仓库。SDK 会读取进程环境变量，但不会自动加载 `.env` 文件；如使用 `.env`，请由应用自行加载。

## 安装与导入

SDK 以本地安装包形式分发，不发布到公开 npm 仓库。从发布包的 `sdk/` 目录取得 `dashscope-sdk-nodejs-0.1.0.tgz`，放入业务项目（例如 `vendor/` 目录）后安装：

```bash
npm install ./vendor/dashscope-sdk-nodejs-0.1.0.tgz
```

安装后，`package.json` 中的依赖记录为 `file:vendor/dashscope-sdk-nodejs-0.1.0.tgz`。请将该 `.tgz` 文件随项目纳入版本管理或内部制品库，以便 CI 和其他成员复现安装。运行时依赖 `ws` 仍从项目配置的 npm 源安装。

ESM 和 TypeScript 可从子路径或主入口导入：

```ts
import { RealtimeClient, DashScopeError } from 'dashscope-sdk-nodejs/realtime'
```

CommonJS 可使用 `require`：

```js
const { RealtimeClient } = require('dashscope-sdk-nodejs/realtime')
```

下文完整示例使用 ESM，保存为对应的 `.mjs` 文件后运行。TypeScript 代码中的 `?` 表示可选参数或字段，`Promise<T>` 表示异步返回 `T`。

## 接口地址

SDK 默认连接 `dashscope.aliyuncs.com`。实时语音对话使用 WebSocket 地址 `wss://{host}/api-ws/v1/realtime?model={model}`，`{host}` 由 `baseUrl` 决定：只给域名时协议与路径由 SDK 补全，`model` 查询参数始终由 SDK 追加并编码。切换地域或改用业务空间专属域名，把 `baseUrl` 换成下表中的域名即可。

| 场景 | `baseUrl` 取值 |
| --- | --- |
| 华北2（北京）公共域名 | 省略，或 `dashscope.aliyuncs.com` |
| 新加坡公共域名 | `dashscope-intl.aliyuncs.com` |
| 华北2（北京）业务空间专属域名 | `{WorkspaceId}.cn-beijing.maas.aliyuncs.com` |
| 新加坡业务空间专属域名 | `{WorkspaceId}.ap-southeast-1.maas.aliyuncs.com` |

**重要**：不同地域的凭据和模型可用性可能不同。切换域名时，请同时核对 API Key、业务空间、模型和音色。`workspaceId` 只用于生成 `X-DashScope-WorkSpace` 请求头，不会改变域名；使用业务空间专属域名须自行写入 `baseUrl`。

## 通用配置（BaseClientOptions）

`RealtimeClientOptions` 继承以下通用参数。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `apiKey` | `string` | 条件必填 | 显式传入的 API Key 优先；省略时读取 `DASHSCOPE_API_KEY`。两者均未提供时构造失败。 |
| `workspaceId` | `string` | 否 | 省略时读取 `DASHSCOPE_WORKSPACE_ID`。提供非空值时附带 `X-DashScope-WorkSpace` 请求头，不改变域名。 |
| `baseUrl` | `string` | 否 | 服务地址，默认 `dashscope.aliyuncs.com`。可只给域名，SDK 补全 `wss://` 与 `/api-ws/v1/realtime`；已带路径的完整地址沿用该路径，`model` 查询参数仍会追加。 |
| `headers` | `Record<string, string>` | 否 | 额外请求头。请避免重复设置鉴权头或业务空间头；显式提供的同名 `Authorization` 可以覆盖默认鉴权值。 |
| `onTrace` | `(event: ClientTraceEvent) => void \| Promise<void>` | 否 | 传输事件回调，记录连接、上下行消息和错误。回调异常不影响请求；URL 和业务数据须按需脱敏，字段见[接入文档](./dashscope-sdk-nodejs接入文档.md)。 |

`workspaceId` 的非空值须是由字母、数字或连字符组成的 1–63 字符 DNS label，不能以连字符开头或结尾。传空字符串表示显式不使用业务空间，不再读取环境变量中的业务空间 ID。

设置 `baseUrl` 不会绕过 API Key 与业务空间参数的构造期校验。非字符串 `baseUrl`、无法解析的地址或不受支持的协议（仅接受 `http`、`https`、`ws`、`wss` 或不带协议的域名）均在构造时抛出 `invalid_request_error`。

## 事件监听

`RealtimeClient` 支持以下方法。

| 方法 | 参数 | 返回值 | 说明 |
| --- | --- | --- | --- |
| `on(event, listener)` | 事件名、监听函数 | `this` | 持续监听事件。事件名与负载在 TypeScript 中有类型提示。 |
| `once(event, listener)` | 事件名、监听函数 | `this` | 仅监听一次。 |
| `off(event, listener?)` | 事件名、可选监听函数 | `this` | 提供函数时移除该监听；省略时移除该事件的全部监听。 |
| `removeAllListeners()` | 无 | `this` | 移除全部事件的监听。 |

**重要**：在 `connect()` 之前注册监听器，使用 `try/catch/finally` 处理异步调用失败并释放资源。未注册 `error` 监听器时，SDK 会通过 `console.warn` 输出错误消息；建议注册监听器并对日志脱敏。

监听器的异常由应用负责处理。SDK 不会等待异步监听器返回的 Promise。

## RealtimeClient

**导入路径**：`dashscope-sdk-nodejs/realtime`，也可从主入口导入。

通过 WebSocket 进行音频输入、音频输出、语音转写和 Function Calling。服务端事件采用扁平的 `type` 字段，与任务式 TTS/ASR 的 `header.event` 结构不同。

**音频规格**：输入为 16 kHz、16-bit、单声道原始 PCM，输出为 24 kHz、16-bit、单声道原始 PCM。SDK 不自动重采样。

### 构造方法

```ts
new RealtimeClient(options: RealtimeClientOptions)
```

### RealtimeClientOptions

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `model` | `string` | 是 | 模型名，例如 `qwen-audio-3.1-realtime-plus`。 |
| `voice` | `string` | 否 | 音色。省略时 SDK 不注入值，使用模型服务默认音色。 |
| `instructions` | `string` | 否 | 系统指令。 |
| `turnDetection` | `TurnDetection \| null` | 否 | 默认 `{ type: 'server_vad' }`；`null` 表示手动提交。 |
| `modalities` | `Modality[]` | 否 | 默认 `['text', 'audio']`，类型为 `text` 或 `audio`。 |
| `maxHistoryTurns` | `number` | 否 | 历史轮数，参数约定范围 1–50、默认 20；省略时由服务端决定。 |
| `tools` | `ToolDefinition[]` | 否 | Function Calling 工具定义。 |
| `inputTranscription` | `{ model?: string; language?: string } \| null` | 否 | 输入音频转写配置；`null` 关闭，省略时不发送此字段。`model` 和 `language` 均可省略，空对象及扩展字段原样透传，SDK 不补默认值。关闭后重新开启可传 `{ model: 'fun-asr', language: 'zh' }`。 |
| `sessionExtras` | `SessionConfig` | 否 | 扩展初始会话配置，最后合并，会覆盖默认项及顶层选项对应字段。 |
| `connectTimeoutMs` | `number` | 否 | 建连超时，默认 10000 ms；请设置正数，`0` 不表示禁用。 |

以上参数还继承通用配置。

### 交互模式（TurnDetection）

| 类型 | 配置 | 说明 |
| --- | --- | --- |
| 声学 VAD | `{ type: 'server_vad', threshold?: number, silence_duration_ms?: number }` | 服务端自动检测语音起止并生成响应。参数约定：threshold 范围 `[-1,1]`、默认 0.5；静音阈值范围 `[200,6000]` ms、默认 800。 |
| 智能轮次 | `{ type: 'smart_turn' \| 'smart_turn_v2', threshold?: number, voiceprint_audio_urls?: string[] }` | 语义与声学融合判断轮次；threshold 范围 `[-1,1]`；声纹参考音频 URL 最多 5 个，能力以模型服务为准。 |
| 手动提交 | `null` | 发送音频后依次调用 `commit()` 和 `createResponse()`。 |

**重要**：`turn_detection`、`voice`、`input_audio_format` 须在首次发送音频前配置并等待 `sessionUpdated`。发送音频后修改这些参数可能被服务端忽略。

### 会话参数（SessionConfig）

`updateSession()` 和 `sessionExtras` 使用以下 snake_case 字段名。

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `modalities` | `Modality[]` | 否 | 输出模态。 |
| `voice` | `string` | 否 | 音色。 |
| `instructions` | `string` | 否 | 系统指令。 |
| `input_audio_format`、`output_audio_format` | `'pcm'` | 否 | 输入、输出音频格式。SDK 初始配置均为 PCM。 |
| `turn_detection` | `TurnDetection \| null` | 否 | 轮次检测或手动提交模式。 |
| `tools` | `ToolDefinition[]` | 否 | 工具列表。 |
| `max_history_turns` | `number` | 否 | 历史轮数。 |
| `input_audio_transcription` | `{ model?: string; language?: string } \| null` | 否 | 用户输入音频转写配置，与 `inputTranscription` 相同。支持 `null` 关闭、空对象及可选字段；提供 `model` 或 `language` 时须为非空白字符串。 |
| `output_audio` | `{ language?: string }` | 否 | 输出目标语种配置。 |
| `speech_rate` | `number` | 否 | 输出语速，参数约定范围 `[0.5,2]`。 |
| `enable_speech_emotion` | `boolean` | 否 | 情感化语音输出开关，参数约定默认 `true`。 |
| `enable_search` | `boolean` | 否 | 联网搜索开关。 |
| `search_options` | `{ enable_source?: boolean }` | 否 | 联网搜索选项，`enable_source` 控制是否返回来源。 |
| 其他字段 | `unknown` | 否 | 按模型协议透传。 |

动态关闭输入转写可调用 `client.updateSession({ input_audio_transcription: null })`；重新开启可调用 `client.updateSession({ input_audio_transcription: { model: 'fun-asr', language: 'zh' } })`。每次更新后通过 `sessionUpdated` 确认服务端配置，再发送后续音频。

### 属性

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `isConnected` | `boolean`，只读 | 当前 WebSocket 是否为 OPEN。不表示服务端已确认会话配置。 |

### connect() - 建立连接并发送初始配置

```ts
connect(): Promise<void>
```

**返回值**：WebSocket 握手成功并发送初始 `session.update` 后兑现，随后 SDK 发出 `open`。

**重要**：`connect()` 不等待 `session.updated`。应在调用前注册 `sessionUpdated` 监听器，并在配置确认后发送依赖该配置的音频。已有连接或正在建连时再次调用会拒绝。

### updateSession() - 更新会话配置

```ts
updateSession(session: SessionConfig): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `session` | `SessionConfig` | 是 | 发送给服务端的会话配置。 |

**返回值**：无，不等待配置确认。确认通过 `sessionUpdated` 事件接收。

### appendAudio() - 追加输入音频

```ts
appendAudio(pcm: Buffer | Uint8Array): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `pcm` | `Buffer \| Uint8Array` | 是 | 16 kHz、16-bit、单声道原始 PCM。SDK 转为 Base64 后发送。 |

**返回值**：无。建议按实时节奏发送，每 100 ms 约 3200 字节。SDK 不校验声道、采样率或 PCM 内容，不做自动节流。

### commit() - 提交输入缓冲区

```ts
commit(): void
```

手动模式提交当前输入音频缓冲区。此调用只提交音频，不等同于生成响应，随后须调用 `createResponse()`。

### clearAudioBuffer() - 清空输入缓冲区

```ts
clearAudioBuffer(): void
```

清空服务端尚未提交的输入缓冲区，常用于手动模式放弃本次录音。不会清空应用本地的播放队列。

### createResponse() - 请求生成响应

```ts
createResponse(response?: Record<string, unknown>): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `response` | `Record<string, unknown>` | 否 | 当前响应的服务端配置，按模型协议透传。 |

**返回值**：无。生成进度和结果通过事件获得。

### cancelResponse() - 取消当前响应

```ts
cancelResponse(): void
```

发送 `response.cancel`。不会关闭整个会话，也不清空应用播放队列；应用需要自行停止播放已缓存音频。

### createConversationItem() - 创建对话项

```ts
createConversationItem(item: ConversationItem, previousItemId?: string): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `item` | `ConversationItem` | 是 | 消息、函数调用或函数输出。 |
| `previousItemId` | `string` | 否 | 目标插入位置的前一项 ID。 |

**返回值**：无。服务端确认或错误可通过原始 `event` 接收。

### submitFunctionCallOutput() - 回写工具结果

```ts
submitFunctionCallOutput(callId: string, output: string, autoCreateResponse?: boolean): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `callId` | `string` | 是 | 对应函数调用 ID，不是函数名。 |
| `output` | `string` | 是 | 工具结果字符串；结构化结果可使用 `JSON.stringify()`。 |
| `autoCreateResponse` | `boolean` | 否 | 默认 `true`，回写后自动调用 `createResponse()`。 |

SDK 不执行工具、不解析参数，也不授权工具访问。函数执行及输入校验由应用负责。

### deleteConversationItem() - 删除对话项

```ts
deleteConversationItem(itemId: string): void
```

`itemId` 为必填的对话项 ID。方法仅发送删除请求，无直接返回值。

### retrieveConversationItem() - 查询对话项

```ts
retrieveConversationItem(itemId: string): void
```

`itemId` 为必填的对话项 ID。方法仅发送查询请求；服务端结果通过原始 `event` 接收，不返回 Promise。

### sendEvent() - 发送自定义事件

```ts
sendEvent(event: ClientEvent): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `event` | `ClientEvent` | 是 | 必须包含 `type: string`，可包含 `event_id?: string` 和其他协议字段。 |

**返回值**：无。未提供 `event_id` 时 SDK 自动生成；显式提供时使用调用方的值。服务端错误通过事件接收，连接未建立时同步抛出参数错误。

### close() - 关闭会话

```ts
close(code?: number, reason?: string): void
```

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `code` | `number` | 否 | WebSocket 关闭码，默认 1000。 |
| `reason` | `string` | 否 | 关闭原因，默认 `client closing`；须满足 WebSocket 关闭帧限制。 |

关闭 WebSocket 后清理当前连接引用，之后可重新 `connect()`。重连会建立新会话，不自动恢复旧会话历史或重发音频。OPEN 状态下非法关闭码（例如 1006）或超过 123 字节的 UTF-8 原因会同步抛出底层异常；连接保持可用，修正参数后可再次关闭。

### 事件（RealtimeEvents）

| 事件 | 负载类型 | 说明 |
| --- | --- | --- |
| `open` | `void` | WebSocket 已建立，SDK 已发送初始配置；不表示配置已确认，也不保证 `session.created` 尚未到达。 |
| `sessionCreated` | `ServerEvent` | 服务端创建会话。 |
| `sessionUpdated` | `ServerEvent` | 服务端确认更新后的会话配置。 |
| `audio` | `Buffer` | 已由 Base64 解码的输出 PCM 音频块。 |
| `audioTranscriptDelta` | `{ delta: string }` | 输出音频的文本转写增量。 |
| `outputTranscript` | `{ transcript: string }` | 输出音频的完整文本转写。 |
| `textDelta` | `{ delta: string }` | 纯文本输出增量，对应 `response.text.delta`，适用于 `modalities: ['text']`。 |
| `textDone` | `{ text: string }` | 纯文本输出完整内容，对应 `response.text.done`。 |
| `inputTranscriptDelta` | `{ text: string; stash: string }` | 当前用户输入转写：`text` 为确定文本，`stash` 为暂存文本。应以 `text + stash` 替换当前显示，而非累计拼接；需开启输入转写。 |
| `inputTranscript` | `{ transcript: string }` | 用户输入音频最终转写，需开启输入转写。 |
| `speechStarted` | `ServerEvent` | 服务端检测到用户开始说话。应用可据此打断本地播放。 |
| `speechStopped` | `ServerEvent` | 服务端检测到用户停止说话。 |
| `responseCreated` | `ServerEvent` | 服务端开始生成响应。 |
| `responseDone` | `ServerEvent` | 响应进入终态，可能为完成、取消或失败；不能一律当作成功。 |
| `functionCall` | `{ callId: string; name: string; arguments: string }` | 完整工具调用参数。`arguments` 是字符串，须由应用解析和校验。 |
| `ambientTranscript` | `{ text: string; stash: string }` | 当前环境音转写，同样采用确定/暂存文本，不写入会话上下文；适用模型和模式以服务端协议为准。 |
| `ambientTranscriptCompleted` | `{ transcript: string }` | 环境音最终转写，不写入会话上下文。 |
| `event` | `ServerEvent` | 原始 JSON 消息，包含未映射到友好事件的协议事件。 |
| `error` | `DashScopeError` | 连接或服务端错误。 |
| `close` | `{ code: number; reason: string }` | 底层连接关闭，不表示当前响应成功。 |

### 结果及工具类型

`ServerEvent` 包含 `type: string`、可选 `event_id: string` 和其他动态协议字段。`responseDone` 返回原始服务端事件，通过 `event.response.status` 检查响应状态。

`ToolDefinition` 的结构如下：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `type` | `'function'` | 工具类型。 |
| `function.name` | `string` | 工具名称。 |
| `function.description` | `string`，可选 | 工具描述。 |
| `function.parameters` | `Record<string, unknown>`，可选 | 函数输入的 JSON Schema。应用仍须验证实际输入。 |

`ConversationItem` 是下列三种类型的联合：

| `type` | 必填字段 | 可选字段 |
| --- | --- | --- |
| `message`（system） | `role: 'system'`、`content: Array<{ type: 'input_text'; text: string }>` | `id?: string`、内容扩展字段 |
| `message`（user） | `role: 'user'`、`content: Array<{ type: 'input_text'; text: string } \| { type: 'input_audio'; audio: string }>` | `id?: string`、内容扩展字段 |
| `message`（assistant） | `role: 'assistant'`、`content: Array<{ type: 'output_text'; text: string }>` | `id?: string`、内容扩展字段 |
| `function_call` | `call_id: string`、`name: string`、`arguments: string` | `id?: string` |
| `function_call_output` | `call_id: string`、`output: string` | `id?: string` |

## 示例代码：单个 PCM 文件的手动提交

保存为 `realtime.mjs`，运行 `node realtime.mjs ./input.pcm ./output.pcm`。

**重要**：文件示例使用手动模式，将整个文件作为一轮输入；不会因文件内的停顿提前生成响应。麦克风多轮对话可改用 VAD，但应持续保持连接，并按响应 ID 管理输出。

示例在配置确认后发送音频，检查响应终态，并处理错误、提前关闭和等待超时。输入文件须自行转换为 16 kHz、16-bit、单声道原始 PCM。

```js
import { readFile, writeFile } from 'node:fs/promises'
import { setTimeout as sleep } from 'node:timers/promises'
import { RealtimeClient } from 'dashscope-sdk-nodejs/realtime'

async function main() {
  const input = process.argv[2]
  const output = process.argv[3] ?? 'output.pcm'
  if (!input) throw new Error('用法：node realtime.mjs <input.pcm> [output.pcm]')
  const pcm = await readFile(input)
  if (!pcm.length || pcm.length % 2) {
    throw new Error('PCM 必须非空且包含完整的 16-bit 采样')
  }

  const client = new RealtimeClient({
    apiKey: process.env.DASHSCOPE_API_KEY,
    workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
    // 服务域名：切换地域或使用业务空间专属域名时修改此处，例如 dashscope-intl.aliyuncs.com
    baseUrl: 'dashscope.aliyuncs.com',
    model: 'qwen-audio-3.1-realtime-plus',
    voice: 'longanqian_v3.1',
    instructions: '你是一位友好的智能语音助手，回答简洁自然。',
    inputTranscription: { language: 'zh' },
    turnDetection: null,
  })
  const audio = []
  let resolveReady
  let rejectReady
  let resolveDone
  let rejectDone
  const ready = new Promise((resolve, reject) => {
    resolveReady = resolve
    rejectReady = reject
  })
  const done = new Promise((resolve, reject) => {
    resolveDone = resolve
    rejectDone = reject
  })
  ready.catch(() => {})

  const fail = (err) => {
    rejectReady(err)
    rejectDone(err)
  }
  client.once('sessionUpdated', () => resolveReady())
  client.on('audio', (chunk) => audio.push(chunk))
  client.on('inputTranscript', ({ transcript }) => console.log('用户：', transcript))
  client.on('outputTranscript', ({ transcript }) => console.log('助手：', transcript))
  client.once('responseDone', (event) => {
    if (event.response?.status === 'completed') resolveDone()
    else fail(new Error(`响应未完成：${event.response?.status ?? 'unknown'}`))
  })
  client.on('error', fail)
  client.on('close', () => fail(new Error('连接在响应完成前关闭')))
  const timer = setTimeout(() => fail(new Error('等待会话或响应超时')), pcm.length / 32 + 60000)

  try {
    await Promise.all([
      done,
      (async () => {
        await client.connect()
        await ready
        for (let offset = 0; offset < pcm.length; offset += 3200) {
          client.appendAudio(pcm.subarray(offset, offset + 3200))
          await sleep(100)
        }
        client.commit()
        client.createResponse()
      })(),
    ])
    await writeFile(output, Buffer.concat(audio))
    console.log('输出音频已写入：', output)
  } finally {
    clearTimeout(timer)
    client.close()
  }
}

main().catch((err) => {
  console.error('调用失败：', err.name, err.code, err.requestId, err.taskId)
  process.exitCode = 1
})
```

输出为 24 kHz 原始 PCM，可转换为 WAV：

```bash
ffmpeg -f s16le -ar 24000 -ac 1 -i output.pcm output.wav
```

## 示例代码：工具调用

对已连接的 `RealtimeClient` 调用 `registerLengthTool(client)`，注册文本长度工具并处理工具调用事件。示例仅执行本地白名单函数，校验模型生成的参数，不将工具名拼接成命令执行。

```js
function registerLengthTool(client) {
  client.updateSession({
    tools: [{
      type: 'function',
      function: {
        name: 'text_length',
        description: '计算文本的 Unicode 码点数量',
        parameters: {
          type: 'object',
          properties: { text: { type: 'string', maxLength: 1000 } },
          required: ['text'],
          additionalProperties: false,
        },
      },
    }],
  })

  client.on('functionCall', ({ callId, name, arguments: args }) => {
    let result
    try {
      if (name !== 'text_length') throw new Error('未知工具')
      const params = JSON.parse(args)
      if (!params || typeof params !== 'object' || Array.isArray(params)
        || typeof params.text !== 'string' || params.text.length > 1000
        || Object.keys(params).length !== 1) {
        throw new Error('工具参数不合法')
      }
      result = { length: Array.from(params.text).length }
    } catch (err) {
      result = { error: err.message }
    }
    if (client.isConnected) {
      client.submitFunctionCallOutput(callId, JSON.stringify(result))
    }
  })
}
```

应用应等待此次工具配置的 `sessionUpdated` 后再请求需要工具的响应。

## 错误处理（DashScopeError）

**导入路径**：`dashscope-sdk-nodejs` 或 `dashscope-sdk-nodejs/realtime`。

SDK 自身的配置、网络和协议错误通常使用 `DashScopeError`，继承自 `Error`。应用自行抛出的错误或监听器异常不一定是该类型。

**重要**：建议日志仅记录错误名、错误码、请求 ID 和任务 ID。错误 `message`、`raw`、`cause` 或完整错误对象可能包含签名 URL 和业务内容，记录前须脱敏。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `name` | `string` | 值为 `DashScopeError`。 |
| `message` | `string` | 错误描述。 |
| `code` | `string`，可选 | SDK 错误码或服务端错误码。 |
| `requestId` | `string`，可选 | 相关请求 ID，不保证所有错误均携带。 |
| `taskId` | `string`，可选 | 相关任务 ID，不保证所有错误均携带。 |
| `fatal` | `boolean` | SDK 对失败严重性的提示，不表示会自动重试或重连。 |
| `raw` | `unknown`，可选 | 原始错误数据，可能包含文本、音频地址或其他敏感信息。 |
| `cause` | `unknown`，可选 | 底层错误原因。 |

### 常见错误

| 错误码 | 含义 | 建议处理 |
| --- | --- | --- |
| `invalid_request_error` | 参数、状态或调用顺序不合法，例如连接未建立就发送事件 | 修正参数或生命周期，不盲目重试。 |
| `timeout` | WebSocket 建连超时 | 排查网络，确认服务可用性。 |
| `network_error`、`connection_error` | 网络或连接失败 | 检查网络和服务可用性；不是所有连接错误都保证携带 code。 |
| `connection_closed` | 连接在预期阶段结束前关闭 | 检查关闭码与错误原因。 |
| `protocol_error` | 收到无法解析或不符合当前协议的消息 | 检查地址和模型协议，保留脱敏诊断信息。 |
| 服务端错误码 | 鉴权、配额、参数、服务端故障等 | 按服务端错误说明处理，提供请求 ID 便于排查。 |

**重要**：SDK 不自动重连或重试。`fatal: true` 不保证 SDK 已主动关闭 WebSocket。不要仅凭 `fatal` 判断能否安全重连；重新连接会建立新会话，不恢复旧会话历史。

## 使用限制与资源释放

| 场景 | 要求 |
| --- | --- |
| 手动模式 | 注册事件后 `connect()`，等待 `sessionUpdated`，追加音频，然后 `commit()` + `createResponse()`；检查 `responseDone` 状态。 |
| VAD 模式 | 按实时节奏持续送音频，由服务端判断轮次；应用管理多轮输出、播放与打断，不在首轮响应后无条件关闭。 |
| 会话配置 | `turn_detection`、`voice`、`input_audio_format` 须在首次发送音频前配置并等待确认。 |
| 音频规格 | 输入 16 kHz、输出 24 kHz，均为 16-bit 单声道 PCM；SDK 不重采样、不做自动节流。 |
| 工具调用 | SDK 不执行工具、不校验参数；应用须白名单工具名并校验模型生成的参数。 |
| 超时与取消 | 不支持 `AbortSignal`。`cancelResponse()` 只取消当前响应，`close()` 关闭整个会话。 |
| 诊断与隐私 | 日志保留错误码、请求 ID、任务 ID 即可；按需脱敏 `raw`、转写文本与音频内容。 |
