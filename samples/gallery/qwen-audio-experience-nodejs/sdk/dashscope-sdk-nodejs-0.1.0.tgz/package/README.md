# Qwen Audio SDK for Node.js

`dashscope-sdk-nodejs` 提供语音合成、实时语音识别、录音文件转写和实时语音对话的 Node.js 客户端，支持 ESM、CommonJS 和 TypeScript。

**版本**：`0.1.0`（预览版）。

## 支持的能力

| 能力 | 客户端 | 协议 | 接口文档 |
| --- | --- | --- | --- |
| 语音合成 | `SpeechSynthesizer` | WebSocket | [语音合成](./dashscope-sdk-nodejs语音合成文档.md) |
| 实时语音识别 | `RecognitionClient` | WebSocket | [实时语音识别](./dashscope-sdk-nodejs实时语音识别文档.md) |
| 录音文件转写 | `TranscriptionClient` | HTTP | [录音文件转写](./dashscope-sdk-nodejs录音文件转写文档.md) |
| 实时语音对话 | `RealtimeClient` | WebSocket | [实时语音对话](./dashscope-sdk-nodejs实时语音对话文档.md) |

安装与公共配置见 [接入文档](./dashscope-sdk-nodejs接入文档.md)。

## 环境要求

- Node.js 18 或以上；SDK 仅用于服务端，不支持在浏览器中直接使用。
- 已开通所用模型服务，并取得 API Key；按需准备业务空间 ID。
- 运行环境可访问所使用的 DashScope 服务域名。
- 实际服务调用可能产生费用。

## 安装

解压 `dashscope-sdk-nodejs-0.1.0.zip`，将其中的 `sdk/dashscope-sdk-nodejs-0.1.0.tgz` 复制到业务项目的 `vendor/` 目录，然后执行：

```bash
npm install ./vendor/dashscope-sdk-nodejs-0.1.0.tgz
```

安装时，运行时依赖 `ws` 会从项目配置的 npm 源下载。请保留 `.tgz` 文件，以便其他环境复现安装。

## 导入

### ESM / TypeScript

```js
import { SpeechSynthesizer } from 'dashscope-sdk-nodejs/tts'
import { RecognitionClient, TranscriptionClient } from 'dashscope-sdk-nodejs/asr'
import { RealtimeClient } from 'dashscope-sdk-nodejs/realtime'
import { DashScopeError } from 'dashscope-sdk-nodejs'
```

### CommonJS

```js
const { SpeechSynthesizer } = require('dashscope-sdk-nodejs/tts')
const { RecognitionClient, TranscriptionClient } = require('dashscope-sdk-nodejs/asr')
const { RealtimeClient } = require('dashscope-sdk-nodejs/realtime')
const { DashScopeError } = require('dashscope-sdk-nodejs')
```

主入口 `dashscope-sdk-nodejs` 也导出上述客户端。

## 连接配置

四个客户端均支持以下构造参数：

| 参数 | 说明 | 默认值 |
| --- | --- | --- |
| `apiKey` | API Key；省略时读取 `DASHSCOPE_API_KEY` | 无，必须提供 |
| `workspaceId` | 业务空间 ID；省略时读取 `DASHSCOPE_WORKSPACE_ID` | 无 |
| `baseUrl` | 服务域名或地址；切换地域或使用业务空间专属域名时修改 | `dashscope.aliyuncs.com` |
| `headers` | 额外请求头 | 无 |
| `onTrace` | 可选传输事件回调，用于查看连接、消息与错误 | 无 |

```js
const connectionOptions = {
  apiKey: process.env.DASHSCOPE_API_KEY,
  workspaceId: process.env.DASHSCOPE_WORKSPACE_ID,
  baseUrl: 'dashscope.aliyuncs.com',
}
```

将这些参数与模型、音色或音频参数一同传入客户端构造方法。`baseUrl` 只填写域名时，SDK 自动补全协议与接口路径；使用自定义地址时，请查看对应接口文档的地址规则。`workspaceId` 只用于生成 `X-DashScope-WorkSpace` 请求头，不改变请求域名。

SDK 不自动加载 `.env` 文件。使用 `.env` 时，请由应用自行加载；服务域名通过 `baseUrl` 参数指定。

## 运行示例

发布包的 `examples/` 目录提供可直接运行的 JavaScript 示例。在该目录中安装依赖并配置凭据：

```bash
cd examples
npm install
export DASHSCOPE_API_KEY='替换为你的 API Key'
export DASHSCOPE_WORKSPACE_ID='替换为你的业务空间 ID'  # 可选
```

Windows PowerShell 中使用 `$env:DASHSCOPE_API_KEY='替换为你的 API Key'` 设置环境变量。

| 示例 | 命令 | 输出 |
| --- | --- | --- |
| 一次性语音合成 | `node tts-once.mjs` | `output-tts.mp3` |
| 流式语音合成 | `node tts-streaming.mjs` | `output-tts-stream.mp3` |
| 实时语音识别 | `node asr-realtime.mjs input.pcm` | 控制台输出识别文本 |
| 录音文件转写 | `AUDIO_URL='你的公网音频 URL' node asr-file.mjs` | `transcription-0.json` 等 |
| 实时语音对话 | `node realtime.mjs input.pcm output.pcm` | `output.pcm` |

切换服务域名时，修改示例中的 `baseUrl`。实时语音识别和实时对话示例需要 16 kHz、16-bit、单声道 PCM 文件，可使用 ffmpeg 转换：

```bash
ffmpeg -i input.mp3 -f s16le -ac 1 -ar 16000 input.pcm
```

实时对话输出为 24 kHz PCM，可转换为 WAV 播放：

```bash
ffmpeg -f s16le -ar 24000 -ac 1 -i output.pcm output.wav
```

## 使用限制

- SDK 不自动重连或重试。连接中断后，由应用重新建立连接。
- SDK 不自动重采样。输入音频的编码、采样率和声道须与请求参数一致。
- 录音文件转写接收服务端可访问的音频 URL，不上传本地文件。
- 预览版的接口在 1.0 之前可能调整。

## 安全提示

不要将 API Key 写入前端代码、日志或源码仓库。记录错误时，优先使用 `name`、`code`、`requestId` 和 `taskId`；`message`、`raw`、`cause` 以及 `onTrace` 中的 URL 和业务数据应按需脱敏。
